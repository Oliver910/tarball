#undef CONFIG_CP
