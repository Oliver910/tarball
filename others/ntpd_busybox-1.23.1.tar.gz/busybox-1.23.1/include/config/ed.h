#undef CONFIG_ED
