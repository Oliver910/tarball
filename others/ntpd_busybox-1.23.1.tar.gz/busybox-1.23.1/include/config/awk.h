#undef CONFIG_AWK
