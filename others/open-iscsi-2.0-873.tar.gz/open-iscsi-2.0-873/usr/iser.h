#ifndef ISER_TRANSPORT
#define ISER_TRANSPORT

struct iscsi_conn;

extern void iser_create_conn(struct iscsi_conn *conn);

#endif
