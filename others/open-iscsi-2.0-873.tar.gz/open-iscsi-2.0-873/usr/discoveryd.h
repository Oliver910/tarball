#ifndef _DISC_DAEMON_H
#define _DISC_DAEMON_H

extern void discoveryd_start(const char *def_iname);

#endif
