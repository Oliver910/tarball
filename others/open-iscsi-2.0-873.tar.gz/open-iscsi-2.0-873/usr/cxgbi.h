#ifndef CXGBI_TRANSPORT
#define CXGBI_TRANSPORT

struct iscsi_conn;

extern void cxgbi_create_conn(struct iscsi_conn *conn);

#endif
