#define MODULE_24_2P
#include "ip1826lib.c"
