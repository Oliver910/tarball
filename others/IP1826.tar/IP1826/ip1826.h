#ifndef IP1826_H
#define IP1826_H
//#define IP1826DEBUG

#define IP1826_IOC_TYPE		0xE0
#define IP1826_READ   _IOC(_IOC_READ, IP1826_IOC_TYPE, 0, 4)
#define IP1826_WRITE  _IOC(_IOC_WRITE, IP1826_IOC_TYPE, 0, 4)

extern void ip1826_mdio_wr(unsigned short pa, unsigned short ra, unsigned short va);
extern unsigned short ip1826_mdio_rd(unsigned short pa, unsigned short ra);

#endif		/* IP1829_H */
