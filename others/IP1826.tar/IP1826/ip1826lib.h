#ifndef _IP1826LIB_H_
#define _IP1826LIB_H_


//#define USER_API
//#define USER_API_DEBUG 

 
struct GeneralSetting
{
	unsigned short addr;
	unsigned short data;
};


#define MAX_VLAN_NUM		32

//chance add 20090106 for relay agent
#define IP1826_MAX_VLAN_ENTRY MAX_VLAN_NUM

//switch registers
#define IP1826_VERSION_ID								0x00

#define	IP1826_GENERAL_MAC_OPERATUON_BEHAVIOR			0x01
#define	IP1826_ETHERNET_PROTOCOL_FRAME_CAPTURE			0x02

#define IP1826_IOGRESS_RATE(n)							(0x03+n)

//chance 20080415
#define IP1826_PORT_RECEIVE								0x1E
#define IP1826_PORT_RECEIVE_01							0x1E
#define IP1826_PORT_RECEIVE_02							0x1F

#define	IP1826_PORT_BASE_PRI							0x22
#define	IP1826_PORT_BASE_PRI_01							0x22
#define	IP1826_PORT_BASE_PRI_02							0x23
#define	IP1826_VLAN_BASE_PRI							0x24
#define	IP1826_VLAN_BASE_PRI_01							0x24
#define	IP1826_VLAN_BASE_PRI_02							0x25
#define	IP1826_IPDS_BASE_PRI							0x26
#define	IP1826_IPDS_BASE_PRI_01							0x26
#define	IP1826_IPDS_BASE_PRI_02							0x27

#define IP1826_SWITCH_MAC								0x28
#define IP1826_SWITCH_MAC_01							0x28
#define IP1826_SWITCH_MAC_23							0x29
#define IP1826_SWITCH_MAC_45							0x2a

#define IP1826_SECURITY_802_1X_ENABLE					0x2b
#define IP1826_SECURITY_802_1X_ENABLE_0					0x2b
#define IP1826_SECURITY_802_1X_ENABLE_1					0x2c

#define	IP1826_USER_DEFINE_TCP_MASK						0x2d
#define	IP1826_USER_DEFINE_TCP_MASK_AB					0x2d
#define	IP1826_USER_DEFINE_TCP_MASK_CD					0x2e

#define	IP1826_USER_DEFINE_TCP_PORT						0x2f
#define	IP1826_USER_DEFINE_TCP_PORT_A					0x2f
#define	IP1826_USER_DEFINE_TCP_PORT_B					0x30
#define	IP1826_USER_DEFINE_TCP_PORT_C					0x31
#define	IP1826_USER_DEFINE_TCP_PORT_D					0x32

#define	IP1826_TCP_UDP_PORTBASE_PRIORITY				0x33
#define	IP1826_TCP_UDP_PORTBASE_PRIORITY_1				0x33
#define	IP1826_TCP_UDP_PORTBASE_PRIORITY_2				0x34
#define	IP1826_TCP_UDP_PORTBASE_PRIORITY_3				0x35

#define	IP1826_TCP_FILTER_PRIORITY						0x36
#define	IP1826_TCP_FILTER_PRIORITY_0					0x36
#define	IP1826_TCP_FILTER_PRIORITY_1					0x37
#define	IP1826_TCP_FILTER_PRIORITY_CMD					0x37

#define	IP1826_COUNTER_STATUS_COMMAND					0x38
#define	IP1826_COUNTER_STATUS_DATA_HI					0x39
#define	IP1826_COUNTER_STATUS_DATA_LO					0x3a

#define	IP1826_COUNTER_SELECTION						0x3b
#define	IP1826_COUNTER_SELECTION_0						0x3b
#define	IP1826_COUNTER_SELECTION_1						0x3c

#define	IP1826_PRI_MODE									0x3d
#define	IP1826_OUT_QUEUE_SCHEDULE_MODE					0x3d
#define	IP1826_OUT_QUEUE_ON_THRESHOLD					0x3e
#define	IP1826_OUT_QUEUE_OFF_THRESHOLD					0x3f

#define IP1826_ARL_OPERATION_SETTING					0x40

#define IP1826_IP_ADDRESS_SECURITY						0x41

#define	IP1826_BROADCAST_STORM_CONTROL					0x42
#define	IP1826_BROADCAST_STORM_CONTROL_01				0x42
#define	IP1826_BROADCAST_STORM_CONTROL_02				0x43
#define	IP1826_AGING_TIMER_n_BCAST_THRESHOLD			0x44

#define IP1826_MAC_ADDR_LEARNING						0x45
#define IP1826_MAC_ADDR_LEARNING_01						0x45
#define IP1826_MAC_ADDR_LEARNING_02						0x46
//chance 20080415
#define IP1826_RECEIVE_FORWARDING						0x47
#define IP1826_RECEIVE_FORWARDING_01					0x47
#define IP1826_RECEIVE_FORWARDING_02					0x48

#define	IP1826_SECURITY_CONFIG							0x49

#define	IP1826_VLAN_UPLINK								0x4a
#define	IP1826_VLAN_UPLINK_00							0x4a
#define	IP1826_VLAN_UPLINK_01							0x4b

#define IP1826_TRUNK_GROUP								0x4c
#define IP1826_TRUNK_GROUP0								0x4c
#define IP1826_TRUNK_GROUP1								0x4d
#define IP1826_TRUNK_GROUP2								0x4e

#define IP1826_MIRROR_SOURCE							0x4f
#define IP1826_MIRROR_SOURCE_01							0x4f
#define IP1826_MIRROR_SOURCE_02							0x50
#define IP1826_MIRROR_DEST								0x51
#define IP1826_MIRROR_DEST_01							0x51
#define IP1826_MIRROR_DEST_02							0x52

#define	IP1826_VLAN_PVID								0x53
#define	IP1826_VLAN_PVID012								0x53
#define	IP1826_VLAN_PVID345								0x54
#define	IP1826_VLAN_PVID678								0x55
#define	IP1826_VLAN_PVID9ab								0x56
#define	IP1826_VLAN_PVIDcde								0x57
#define	IP1826_VLAN_PVIDfgh								0x58
#define	IP1826_VLAN_PVIDijk								0x59
#define	IP1826_VLAN_PVIDlmn								0x5a
#define	IP1826_VLAN_PVIDopq								0x5b

#define	IP1826_VLAN_TAG_ADD								0x5c
#define	IP1826_VLAN_TAG_ADD_00							0x5c
#define	IP1826_VLAN_TAG_ADD_01							0x5d
#define	IP1826_VLAN_TAG_RMV								0x5e
#define	IP1826_VLAN_TAG_RMV_00							0x5e
#define	IP1826_VLAN_TAG_RMV_01							0x5f

#define	IP1826_VLAN_VID									0x60

#define	IP1826_VLAN_MEMBER								0x80
#define	IP1826_VLAN_MEMBER_LOW(n)						(0x80+2*n)
#define	IP1826_VLAN_MEMBER_HIGH(n)						(0x81+2*n)

#define	IP1826_IGMP_SNOOPING_FUNCTION					0xc0

#define	IP1826_IGMP_ROUTER_PORT_SELECTION				0xc1
#define	IP1826_IGMP_ROUTER_PORT_SELECTION_0				0xc1
#define	IP1826_IGMP_ROUTER_PORT_SELECTION_1				0xc2

#define	IP1826_PACKET_SELECT_PORT						0xc3
#define	IP1826_PACKET_SELECT_PORT_1						0xc3
#define	IP1826_PACKET_SELECT_PORT_2						0xc4

#define	IP1826_ACCESS_LUT_COMMAND						0xc5
#define	IP1826_ACCESS_LUT_DATA_1						0xc6
#define	IP1826_ACCESS_LUT_DATA_2						0xc7
#define	IP1826_ACCESS_LUT_DATA_3						0xc8

#define IP1826_PORT_EXCLUDING							0xc9
#define IP1826_PORT_EXCLUDING01							0xc9
#define IP1826_PORT_EXCLUDING02							0xca

#define IP1826_AUTO_NWAY								0xcb
#define IP1826_AUTO_NWAY01								0xcb
#define IP1826_AUTO_NWAY02								0xcc

#define IP1826_SPEED									0xcd
#define IP1826_SPEED01									0xcd
#define IP1826_SPEED02									0xce
#define IP1826_SPEED03									0xcf

#define IP1826_DUPLEX									0xd0
#define IP1826_DUPLEX01									0xd0
#define IP1826_DUPLEX02									0xd1

#define IP1826_PAUSE									0xd2
#define IP1826_PAUSE01									0xd2
#define IP1826_PAUSE02									0xd3

#define IP1826_ASYMMERTIC_PAUSE							0xd4
#define IP1826_ASYMMERTIC_PAUSE_01						0xd4
#define IP1826_ASYMMERTIC_PAUSE_02						0xd5

#define IP1826_BACKPRESSURE								0xd6
#define IP1826_BACKPRESSURE01							0xd6
#define IP1826_BACKPRESSURE02							0xd7

#define IP1826_TRANSMIT_ENABLE							0xd8
#define IP1826_TRANSMIT_ENABLE_01						0xd8
#define IP1826_TRANSMIT_ENABLE_02						0xd9

#define IP1826_PHY_CMD									0xda
#define IP1826_PHY_DATA									0xdb
#define IP1826_PCS_CMD									0xda
#define IP1826_PCS_DATA									0xdb

#define IP1826_LED										0xdd

#define IP1826_PORT_STATUS								0xde
#define IP1826_PORT_STATUS_01_03						0xde
#define IP1826_PORT_STATUS_04_06						0xdf
#define IP1826_PORT_STATUS_FIBER						0xe6

#define IP1826_FIBER_SETTING							0xff

// Define for Spanning Tree
#define IP1826_LUT      			0xF1
#define IP1826_CPU_MODE  			0xF2
#define IP1826_SPECIAL_TAG_SETTING	0xF3

#define IP1826_TCP_FILTER			0xf4
#define IP1826_TCP_FILTER_0			0xf4
#define IP1826_TCP_FILTER_1			0xf5

#define IP1826_EEPROM_COMMAND		0xfb
#define IP1826_EEPROM_DATA			0xfc




unsigned short ip1826_read_reg(unsigned char regad);
void ip1826_write_reg(unsigned char regad, unsigned short Regdata);
//========================================================================================
//		VLAN
//========================================================================================


/*	Set vlan id for this entry
 *	idx:			vlan table entry(0~31)
 *	vid:			vlan id value for this entry(1~4094)
 */
void vlan_set_vid(unsigned char idx,unsigned short vid);
unsigned short vlan_get_vid(unsigned char idx);

/*	Set unicast Packet across VLAN enabled
 *	enabled:		1-enabled
 *					0-disabled
 */
void vlan_set_across_vlan(unsigned char enabled);
unsigned char vlan_get_across_vlan(void);

/*	Set VLAN Mode
 *	vlan_mode:		1-Tag based VLAN
 *					0-Port based VLAN
 */
#define TAG_BASED_VLAN  1
#define PORT_BASED_VLAN 0
void vlan_set_mode(unsigned char vlan_mode);
unsigned char vlan_get_mode(void);

/*	Set Add Tag handling rule
 *	mode:	0 - set vlan member
 *			1 - set add tag for wach VID for tag base vlan
 *			2 - set remove tag for wach VID for tag base vlan
 *			3 - reserved
 */
#define VLAN_TAG_RULE_MEMBER	0
#define VLAN_TAG_RULE_ADDTAG	1
#define VLAN_TAG_RULE_RMVTAG	2
void vlan_set_tag_handling(unsigned char mode);
unsigned char vlan_get_tag_handling(void);

/*	Set Member Port for this entry
 *	idx:			physical port number(0~23) or vlan table entry(0~31)
 *	member_port:	member port for this entry. for bit#: 
 *					1->port # is a member of this entry
 *					0->port # is not a member of this entry
 */
void vlan_set_member(unsigned char idx,unsigned long member_port);
unsigned long vlan_get_member(unsigned char idx);

/*	Set VLAN Tag Mode
 *	mode:	0- Tag/Untag based on Ports
 *	        1-           based on VID
 */
#define VLAN_TAG_MODE_PORT  0
#define VLAN_TAG_MODE_VID   1
void vlan_set_tag_mode(unsigned char mode);
unsigned char vlan_get_tag_mode(void);

/*	Set Add Tag Port base on port
 *	addtag_port:	addtag port for this entry. for bit#: 
 *					1->add tag when port # is output port
 *					0->do not add tag when port # is output port
 */
void vlan_set_addtag(unsigned long addtag_port);
unsigned long vlan_get_addtag(void);

/* 	Set Rmv Tag Port base on port
 * 	rmvtag_port:	rmvtag port for this entry. for bit#: 
 * 					1->remove tag when port # is output port
 * 					0->keep the tag when port # is output port
 */	
void vlan_set_rmvtag(unsigned long rmvtag_port);
unsigned long vlan_get_rmvtag(void);

/*	Set Add Tag Port for this entry base on vid
 *	idx:            vlan table entry(0~31)
 *	addtag_port:	addtag port for this entry. for bit#: 
 *					1->add tag when port # is output port
 *					0->do not add tag when port # is output port
 */
void vlan_set_addtag_vid(unsigned char idx, unsigned long addtag_port);
unsigned long vlan_get_addtag_vid(unsigned char idx);

/* 	Set Rmv Tag Port for this entry base on vid
 *	idx:            vlan table entry(0~31)
 * 	rmvtag_port:	rmvtag port for this entry. for bit#: 
 * 					1->remove tag when port # is output port
 * 					0->keep the tag when port # is output port
 */	
void vlan_set_rmvtag_vid(unsigned char idx, unsigned long rmvtag_port);
unsigned long vlan_get_rmvtag_vid(unsigned char idx);

/*	Set pvid for this port
 *	port_num:		physical port number(0~23)
 *	pvid:			pvid value for this port(0~31)
 */
void vlan_set_pvid(unsigned char port_num,unsigned char pvid);
unsigned char vlan_get_pvid(unsigned char port_num);

/*	Set blocked packets forward to uplink port enabled
 *	enabled:		1-Enabled
 *					0-Disabled
 */
void vlan_set_uplink_enable(unsigned char enabled);
unsigned char vlan_get_uplink_enable(void);

/*	Set Uplink port for this port
 *	port_num:		physical port number(0~23)
 *	uplink:			for bit#
 *					TRUE - This port is an uplink port 
 * 					FALSE - This port is a normal port
 */
void vlan_set_uplink(unsigned long uplink);
unsigned long vlan_get_uplink(void);


//========================================================================================
//		QOS
//========================================================================================
#define MAX_PROTOCOL_NUM	MAX_SYS_PROTOCOL_NUM+MAX_USER_PROTOCOL_NUM
#define MAX_SYS_PROTOCOL_NUM	20
#define MAX_USER_PROTOCOL_NUM	4
#define MAX_SYS_CODEPOINT_NUM	7

enum tcpudp_protocols{
	FTP,
	SSH,
	TELNET,	
	SMTP,
	DNS,

	TFTP,
	HTTP,
	POP3,
	NEWS,
	SNTP,

	NETBIOS,
	IMAP,
	SNMP,
	HTTPS,
	MSN,//1863

	XRD_RDP,//3389
	QQ,//4000,8000
	ICQ,//5190
	YAHOO,//5050
	DHCP,

	USER_A,
	USER_B,
	USER_C,
	USER_D
};
struct _user_protocol_entry
{
	unsigned short port;
	unsigned char mask;
};
struct _qos_setting
{
	unsigned char	schedule_mode;
	unsigned char	queue_low_WRR_weight;
	unsigned char	queue_high_WRR_weight;
	/*
	 * The following 3 priority mode is based on each port.
	 * while bit# refers to port(#)
	 * 1:enable
	 * 0:disable
	 */
	unsigned long	port_enable;
	unsigned long	tag_enable;
	unsigned long	cos_enable;

	unsigned char	protocol_func[MAX_SYS_PROTOCOL_NUM];
	struct _user_protocol_entry	user_protocol_port[MAX_USER_PROTOCOL_NUM];

	unsigned char	low_priority;
};

/*	Set The scheduling mode
 *	mode:	0 - FIFO
 *			1 - SP_2QUEUE
 *			2 - WRR
 *			3 - undefined
 */
#define QOS_SCHEDULE_MODE_FIFO			0
#define QOS_SCHEDULE_MODE_SP			1
#define QOS_SCHEDULE_MODE_WRR			2

void qos_set_schedule_mode(unsigned char mode);
unsigned char qos_get_schedule_mode(void);

/*
 *	Set priority queue weight number when in WRR mode
 *	The weight value between 0~7
 */
#define	QOS_QUEUE_LOW	0
#define	QOS_QUEUE_HIGH	1
void qos_set_queue_weight(unsigned char mode, unsigned char weight);
unsigned char qos_get_queue_weight(unsigned char mode);

/*	Set Port base priority enable for this port
 *	port_num:   physical port number(0~23)
 *	enabled:	1 - enabled tag-based priority for this port
 *				0 - disable tag-based priority for this port
 */
void qos_set_port_enable(unsigned char port_num,unsigned char enabled);
unsigned char qos_get_port_enable(unsigned char port_num);
void qos_set_port(unsigned long port);
unsigned long qos_get_port(void);

/*	Set tag-based priority enabled for this port
 *	port_num:	physical port number(0~23)
 *	enabled:	1 - enabled tag-based priority for this port
 *				0 - disable tag-based priority for this port
 */
void qos_set_tag_enable(unsigned char port_num,unsigned char enabled);
unsigned char qos_get_tag_enable(unsigned char port_num);
void qos_set_tag(unsigned long port);
unsigned long qos_get_tag(void);

/*	Set IP COS-based priority enabled for this port
 *	port_num:	physical port number(0~23)
 *	enabled:	1 - enabled cos-based priority for this port
 *				0 - disable cop-based priority for this port
 */
void qos_set_cos_enable(unsigned char port_num,unsigned char enabled);
unsigned char qos_get_cos_enable(unsigned char port_num);
void qos_set_cos(unsigned long port);
unsigned long qos_get_cos(void);

/*	Set TCP/UDP port-based priority function for this port
 *	idx:   tcp/udp protocol index
 *	func:	00: Disable
 *			01: Drop /Forward to CPU
 *			10: Low priority
 *			11: High priority
 */
#define QOS_PORT_DISABLE		0
#define QOS_PORT_DROP_FORWARD	1
#define QOS_PORT_LOW_PRIORITY	2
#define QOS_PORT_HIGH_PRIORITY	3
void set_protocol_func(unsigned char idx,unsigned char func);
unsigned char get_protocol_func(unsigned char idx);

/*	Set User-defined ranged TCP/UDP port-based priority parameter
 *	idx:	index of user-defined TCP/UDP port 0~3	(A, B, C, D)
 *	port:	defined port
 */
void set_user_protocol_port(unsigned char idx,unsigned short port);
unsigned short get_user_protocol_port(unsigned char idx);

/*	Set User-defined ranged TCP/UDP port-based priority parameter
 *	idx:	index of user-defined TCP/UDP port 0~3	(A, B, C, D)
 *	mask:	defined mask
 */
void set_user_protocol_mask(unsigned char idx,unsigned char mask);
unsigned char get_user_protocol_mask(unsigned char idx);

/*	TCP/UDP destination port number based priority.
 *	0: Drop packet
 *	1: Forward to CPU-port.
 *	This setting is invalid for port 24 and port 25 when they are working in Gigabit mode.
 *	This bit affects register 33h, 34h and 35h.
 */
#define QOS_CPU_DROP	0
#define QOS_CPU_FORWARD	1
void qos_set_cpu_forward(unsigned char enabled);
unsigned char qos_get_cpu_forward(void);
/*	TCP/UDP port number based packet to low priority.
 *	0: Disable; 1: Enable
 *	A packet with TCP/UDP port number defined as low priority in
 *	register 33h~35h will be treated as a low priority packet; regardless
 *	of port based/ tag based/ IP based priority setting, meaning that it
 *	overwrites other settings.
 */
void qos_set_low_priority(unsigned char enabled);
unsigned char qos_get_low_priority(void);

void qos_set_all(struct _qos_setting *qos_setting);
//========================================================================================
//		SECURITY
//========================================================================================
#define MAX_L2_PROTOCOL_NUM			5
#define MAX_L3_PROTOCOL_NUM			5

struct _security_setting
{
	/* mac_enable is based on each port.
	 * while bit# refers to port(#)
	 * 1:enable
	 * 0:disable
	 */
	unsigned long	mac_enable;
	/*	Set MAC filter Function for unknown SA packets
	 *	func(bit0,1):	0 - DROP
	 *					2 - Broadcast
	 *					3 - Broadcast with CPU port
	 */
	unsigned char	mac_func;
	/*	Bit0 ~23:   1 - enable filter   0 - disable filter
	 */
	unsigned long	auth_enable;
	/*
	 * 	Bit0:		1 - enable 802.1x filter
	 * 				0 - disable 802.1x filter	 
	 */
	unsigned char	auth_func;
	/*	Set IP Address filter type
	 *	type:	1 - Filter IP address according to destination IP
	 *			0 - Filter IP address according to source IP
	 */
	unsigned char	ip_type;
	/*	Set IP Address filter mode
	 *	mode:	0 - only IP doesn't match to IP table can pass
	 *			1 - only IP matches to IP table can pass
	 *			2 - only both IP & port match to IP table can pass
	 *			3 - only both IP & port doesn't match to IP table can pass
	 */
	unsigned char	ip_filter_mode;
	/*	IP table entry setting mode
	 *	mode:	0 - Set by 32 bits IP hashing result
	 *			1 - Set by source port
	 */
	unsigned char	ip_entry_mode;
	/*	Set IP Address filter shift mode
	 *	mode:	0 - Disable IP shift
	 *			5 - IP Address Add by 1(while enabled bit2 is set to 1)
	 *			6 - IP Address Add by 2
	 *			7 - IP Address Add by 3
	 */
	unsigned char	ip_shift;
	/*	Bit0 ~24:   1 - enable filter   0 - disable filter
	 */
	unsigned long	protocol_filter;
	/*	Bit0 ~19:	Drop default protocols
	 *	Bit20 ~22:	Drop user-defined protocols
	 */
	unsigned long	protocol_drop;

	/*	For L2 protocols:	2- forward to DA/Broadcast 1 - Forward to CPU only 0 - Drop
	 *	For L3 protocols: 3- drop 2- send to CPU only 1- send to both CPU & DA 0- send to DA only
	 */
	unsigned char	l2l3_func[MAX_L2_PROTOCOL_NUM+MAX_L3_PROTOCOL_NUM];
};

/*	Set MAC filter enabled for this port
 *	port_num:	physical port number(0~23)
 *	enabled:	1 - enabled
 *				0 - disable
 */
/*	Since MAC LUT is not implemented yet.
 *	This function is not implemented yet either.
 *	This function simply calls port_set_learning 
 *	and disable learning to enable mac filter.
 */
void security_set_mac_enable(unsigned char port_num,unsigned char enabled);
unsigned char security_get_mac_enabled(unsigned char port_num);

/*	Set MAC filter Function for unknown SA packets
 *	func(bit0,1):	0 - drop all unknow packet
 *					1 - drop all unknow packet
 *					2 - farword unknow packet to all port
 *					3 - farword unknow packet to all port but CPU port
 */
#define SECURITY_MAC_NSA_DROP			1
#define SECURITY_MAC_NSA_BCAST			2
#define SECURITY_MAC_NSA_BCAST_NO_CPU	3
void security_set_mac_func(unsigned char func);
unsigned char security_get_mac_func(void);

/*	Set 802.1X filter enabled for this port
 *	port_num:	physical port number(0~25)
 *	enabled:	1 - enabled
 *				0 - disable
 */
void security_set_auth_enable(unsigned char port_num,unsigned char enabled);
unsigned char security_get_auth_enable(unsigned char port_num);
void security_set_auth(unsigned long port);
unsigned long security_get_auth(void);
/*	Set 802.1X filter function
 *	func:
 *		bit2:	1 - enable 802.1X filter  0 - disable 802.1X filter 
 */
#define SECURITY_AUTH_ENABLE		1
#define SECURITY_AUTH_DISABLE		0
void security_set_auth_func(unsigned char func);
unsigned char security_get_auth_func(void);

/*	Set IP Address filter function enable
 *	enable:	1 - enable
 *			0 - disable
 */
void security_set_ip_filter_enable(unsigned char enable);
unsigned char security_get_ip_filter_enable(void);

/*	Set IP Address filter type
 *	type:	1 - Filter IP address according to destination IP
 *			0 - Filter IP address according to source IP
 */
#define SECURITY_IP_TYPE_DESTINATION		1
#define SECURITY_IP_TYPE_SOURCE				0
void security_set_ip_type(unsigned char type);
unsigned char security_get_ip_type(void);

/*	Set IP Address filter mode
 *	mode:	0 - only IP doesn't match to IP table can pass
 *			1 - only IP matches to IP table can pass
 *			2 - only both IP & port match to IP table can pass
 *			3 - only both IP & port doesn't match to IP table can pass
 */
#define SECURITY_IP_FMODE_IP_MISMATCH				0
#define SECURITY_IP_FMODE_IP_MATCH					1
#define SECURITY_IP_FMODE_IP_MATCH_PORT_MATCH		2
#define SECURITY_IP_FMODE_IP_MATCH_PORT_MISMATCH	3
void security_set_ip_filter_mode(unsigned char mode);
unsigned char security_get_ip_filter_mode(void);

/*	IP table entry setting mode
 *	mode:	0 - Set by 32 bits IP hashing result
 *			1 - Set by source port
 */
#define SECURITY_IP_EMODE_HASH				0
#define SECURITY_IP_EMODE_SOURCE_PORT		1
void security_set_ip_entry_mode(unsigned char mode);
unsigned char security_get_ip_entry_mode(void);

/*	Set IP Address filter shift mode
 *	mode:	0 - Disable IP shift
 *			5 - IP Address Add by 1(while enabled bit2 is set to 1)
 *			6 - IP Address Add by 2
 *			7 - IP Address Add by 3
 */
#define SECURITY_IP_SHIFT_DISABLE			0
#define SECURITY_IP_SHIFT1					5
#define SECURITY_IP_SHIFT2					6
#define SECURITY_IP_SHIFT3					7
void security_set_ip_shift(unsigned char shift);
unsigned char security_get_ip_shift(void);

/*	Set L2/L3 protocol filter function
 *	idx:	1~5 are L2 protocols (1bit per pro.)
 *			6~15 are L3 protocols (2bits per pro.)
 *	func:
 *		For L2 protocols:
 *			STP, EAPOL:		0 - Drop
 *							1 - Forward to CPU
 *			LACP:			0 - Drop
 *							1 - Send to CPU only
 *			GxRP:			0 - Broadcast
 *							1 - Send to CPU only
 *			ARP:			0 - Forward according to DA
 *							1 -	Forward to DA and CPU port
 *							
 *		For L3 protocols:	0- send to DA only
 *							1- send to both CPU & DA 
 *							2- send to CPU only 
 *							3- drop 
 */
#define SECURITY_IN_BAND_MANAGEMENT				0
// 1bit
#define SECURITY_ETHERNET_PROTOCOL_STP			1
#define SECURITY_ETHERNET_PROTOCOL_EAPOL		2	//slow protocal/802.1x/EAPOL
#define SECURITY_ETHERNET_PROTOCOL_LACP			3
#define SECURITY_ETHERNET_PROTOCOL_GXRP			4
#define SECURITY_ETHERNET_PROTOCOL_ARP			5
//2 bits
#define SECURITY_ETHERNET_PROTOCOL_ICMP			6
#define SECURITY_ETHERNET_PROTOCOL_TCP			8
#define SECURITY_ETHERNET_PROTOCOL_UDP			10
#define SECURITY_ETHERNET_PROTOCOL_OSPF			12
#define SECURITY_ETHERNET_PROTOCOL_OTHER		14

#define SECURITY_L2_FUNC_0						0
#define SECURITY_L2_FUNC_1						1

#define SECURITY_L3_FUNC_FORWARD_DA				0
#define SECURITY_L3_FUNC_FORWARD_DA_CPU			1
#define SECURITY_L3_FUNC_FORWARD_CPU			2
#define SECURITY_L3_FUNC_DROP					3
void security_set_l2l3_func(unsigned char idx,unsigned char func);
unsigned char security_get_l2l3_func(unsigned char idx);

void security_set_all(struct _security_setting security_setting);

//========================================================================================
// ACL
//========================================================================================
struct _acl_entry
{
	unsigned char	index;
	unsigned char	source_entry;
	unsigned long	sip;
	unsigned long	dip;
	unsigned short	sport;
	unsigned short	dport;
	unsigned char	action;
};

/*	Set source port/VLAN entry for this acl entry
 *	idx:			acl entry index(0 ~ 15)
 *	source_entry:	ACL source port entry(0-24) or
 *					ACL VLAN entry(0-31)
 */
void acl_set_source_entry(unsigned char idx,unsigned char source_entry);
unsigned char acl_get_source_entry(unsigned char idx);

/*	Set source IP entry for this acl entry
 *	idx:			acl entry index(0 ~ 15)
 *	sip:	ACL source IP(0x00000000 - 0xffffffff,0.0.0.0 - 255.255.255.255)
 */
void acl_set_sip(unsigned char idx,unsigned long sip);
unsigned long acl_get_sip(unsigned char idx);

/*	Set destination IP entry for this acl entry
 *	idx:			acl entry index(0 ~ 15)
 *	dip:	ACL destination IP(0x00000000 - 0xffffffff,0.0.0.0 - 255.255.255.255)
 */
void acl_set_dip(unsigned char idx,unsigned long dip);
unsigned long acl_get_dip(unsigned char idx);

/*	Set source port entry for this acl entry
 *	idx:			acl entry index(0 ~ 15)
 *	sport:	ACL source TCP/UDP port(0 - 65535)
 */
void acl_set_sport(unsigned char idx,unsigned short sport);
unsigned short acl_get_sport(unsigned char idx);

/*	Set destination port entry for this acl entry
 *	idx:			acl entry index(0 ~ 15)
 *	sport:	ACL destination TCP/UDP port(0 - 65535)
 */
void acl_set_dport(unsigned char idx,unsigned short dport);
unsigned short acl_get_dport(unsigned char idx);

/*	Set destination port entry for this acl entry
 *	idx:			acl entry index(0 ~ 15)
 *	action:	ACL action(0 - 9)
 */
#define	ACL_ACTION_DROP			0
#define	ACL_ACTION_FORWARD_CPU	1
#define	ACL_ACTION_QUEUE0		2
#define ACL_ACTION_QUEUE1		3
#define ACL_ACTION_QUEUE2		4
#define	ACL_ACTION_QUEUE3		5
#define	ACL_ACTION_QINQ_TAG0	6
#define	ACL_ACTION_QINQ_TAG1    7
#define ACL_ACTION_QINQ_TAG2    8
#define ACL_ACTION_QINQ_TAG3    9
void acl_set_action(unsigned char idx,unsigned char action);
unsigned char acl_get_action(unsigned char idx);

#define MAX_ACL_ENTRY_NUM	16

struct _acl_setting
{
	struct _acl_entry acl_entry[MAX_ACL_ENTRY_NUM];
};

void acl_set_all(struct _acl_setting *acl_setting);

//========================================================================================
// PORT SET
//========================================================================================

/*	Set power status for this port
 *	port_num:	physical port number(0~25)
 *	enabled:	1 - power up
 *				0 - power down
 */
void port_set_enable(unsigned char port_num,unsigned char enabled);
unsigned char port_get_enable(unsigned char port_num);

/*	Distinguish this port is base on TP or fiber
 *	port_num:	physical port number(0~25)
 */
#define PORT_BASE_UNLINK	2
#define PORT_BASE_FIBER		1
#define PORT_BASE_TP		0
unsigned char port_get_fiber(unsigned char port_num);

/*	Set combo auto-detection mode for port 24, 25 GBIC + 1000Base-T combo interface.
 *	enabled:	1 - enabled
 *				0 - disable
 */
void port_set_fiber_AD(unsigned char enabled);

/*	Set restart Auto-Negotiation for fiber port
 *	port_num:	physical port number(0, 1)=(24, 25)
 */
void port_set_restart_AN_fiber(unsigned char port_num);

/*	Set restart Auto-Negotiation for this port
 *	port_num:	physical port number(0~25)
 */
void port_set_restart_AN(unsigned char port_num);

/*	Set Auto-Negotiation enabled forfiber port
 *	port_num:	physical port number(0, 1)=(24, 25)
 *	enabled:	1 - enabled
 *				0 - disable
 */
void port_set_auto_fiber(unsigned char port_num,unsigned char enabled);
unsigned char port_get_auto_fiber(unsigned char port_num);

/*	Set Auto-Negotiation enabled for this port
 *	port_num:	physical port number(0~25)
 *	enabled:	1 - enabled
 *				0 - disable
 */
void port_set_auto(unsigned char port_num,unsigned char enabled);
unsigned char port_get_auto(unsigned char port_num);

/*	Check Auto-Negotiation has been complete.
 *	port_num:	physical port number(0~25)
 */
unsigned char port_get_an_complete(unsigned char port_num);

void port_set_auto_all(unsigned long port);
unsigned long port_get_auto_all(void);

/*	Set speed for this port
 *	port_num:	physical port number(0~23)
 *	enabled:	1 - 100 M
 *				0 - 10 M
 */
#define PORT_SPEED_1000M	2
#define PORT_SPEED_100M		1
#define PORT_SPEED_10M		0
void port_set_speed(unsigned char port_num,unsigned char mode);
unsigned char port_get_speed(unsigned char port_num);
void port_set_speed_all(unsigned long port);
unsigned long port_get_speed_all(void);
/*	Set Giga speed for this port
 *	port_num:	physical port number(0, 1)=(24, 25)
 *	enabled:	1 - 1000 M
 *				0 - 10M or 100M
 */
void port_set_speed_GIGA(unsigned char port_num,unsigned char mode);
unsigned char port_get_speed_GIGA(unsigned char port_num);
/*	Set MDI/MDIX auto enabled/disable for this port
 *	port_num:	physical port number(0~25)
 *	enabled:	1 - Enable MDI/MDIX auto mode.
 *				0 - Disable MDI/MDIX auto mode.
 */
void port_set_mdi_auto(unsigned char port_num,unsigned char enabled);
unsigned char port_get_mdi_auto(unsigned char port_num);
/*	Set MDI/MDIX for this port
 *	port_num:	physical port number(0~23)
 *	mode:	1 - MDIX mode
 *		    0 - MID mode
 */
void port_set_mdi_mode(unsigned char port_num,unsigned char mode);
unsigned char port_get_mdi_mode(unsigned char port_num);

/*	Set Duplex Mode for this port
 *	port_num:	physical port number(0~23)
 *	enabled:	1 - 100 M
 *				0 - 10 M
 */
#define PORT_DUPLEX_FULL	1
#define PORT_DUPLEX_HALF	0
void port_set_duplex(unsigned char port_num,unsigned char mode);
unsigned char port_get_duplex(unsigned char port_num);
void port_set_duplex_all(unsigned long port);
unsigned long port_get_duplex_all(void);

/*	Set Receive enable for this port
 *	port_num:	physical port number(0~26)
 *	enabled:		0-Disable	1-Enable
 */
void port_set_rx_enable(unsigned char port_num,unsigned char enabled);
unsigned char port_get_rx_enable(unsigned char port_num);
void port_set_rx_enable_all(unsigned long ports);
unsigned long port_get_rx_enable_all(void);
/*	Set Transmit enable for this port
 *	port_num:	physical port number(0~26)
 *	enabled:		0-Disable	1-Enable
 */
void port_set_tx_enable(unsigned char port_num,unsigned char enabled);
unsigned char port_get_tx_enable(unsigned char port_num);
void port_set_tx_enable_all(unsigned long ports);
unsigned long port_get_tx_enable_all(void);
/*	Set learning enable for this port
 *	port_num:	physical port number(0~26)
 *	enabled:		0-Disable	1-Enable
 */
void port_set_learning(unsigned char port_num,unsigned char enalbed);
unsigned char port_get_learning(unsigned char port_num);
void port_set_learning_all(unsigned long ports);
unsigned long port_get_learning_all(void);
/*	Set forwarding state for this port
 *	port_num:	physical port number(0~26)
 *	enabled:		0-Disable	1-Enable
 */
void port_set_forwarding(unsigned char port_num, unsigned char enabled);
unsigned char port_get_forwarding(unsigned char port_num);
void port_set_forwarding_all(unsigned long ports);
unsigned long port_get_forwarding_all(void);

/*	Set pause(rx/tx) enable for fiber port
 *	port_num:	physical port number(0, 1)=(24, 25)
 *	enabled:	1 - enable
 *				0 - disable
 */
void port_set_pause_fiber(unsigned char port_num,unsigned char enabled);
unsigned char port_get_pause_fiber(unsigned char port_num);

/*	Set pause(rx/tx) enable for this port
 *	port_num:	physical port number(0~23)
 *	type:		1 -	TX
 *				0 - RX
 *	enabled:	1 - enable
 *				0 - disable
 */
#define PAUSE_RX	0
#define PAUSE_TX	1
void port_set_pause(unsigned char port_num,unsigned char type,unsigned char enabled);
unsigned char port_get_pause(unsigned char port_num,unsigned char type);
void port_set_pause_all(unsigned char type,unsigned long port);
unsigned long port_get_pause_all(unsigned char type);
/*	Set backpressure enable for this port
 *	port_num:	physical port number(0~23)
 *	enabled:	1 - enable
 *				0 - disable
 */
void port_set_backpressure(unsigned char port_num,unsigned char enabled);
unsigned char port_get_backpressure(unsigned char port_num);
void port_set_backpressure_all(unsigned long port);
unsigned long port_get_backpressure_all(void);
/*	Set backpressure function 
 *	func:		1 - Collision based
 *				0 - Carrier Sense based
 */
#define	BACKPRESSURE_COLLISION	1
#define BACKPRESSURE_CS			0
void port_set_backpressure_func(unsigned char func);
unsigned char port_get_backpressure_func(void);

/*	Set broadcast storm protection enable for this port
 *	port_num:	physical port number(0~23)
 *	enabled:	1 - enable
 *				0 - disable
 */
void port_set_broadcast_storm_protection(unsigned char port_num,unsigned char enabled);
unsigned char port_get_broadcast_storm_protection(unsigned char port_num);

/*	Set broadcast storm protection threshold
 *	value:	0 ~ 63 packets
 */
void port_set_broadcast_storm_threshold(unsigned char value);
unsigned char port_get_broadcast_storm_threshold(void);

/*	Set Port Mirror
 *	type:	0-	Set watching ports
 *			1-	Set mirrored ports
 *	port_num:	bit# set to 1 - set port#
 *							0 - unset port#
 */
#define MIRROR_SOURCE_PORTS		0
#define MIRROR_DEST_PORTS		1
void port_set_port_mirror(unsigned char type,unsigned long port_num);
unsigned long port_get_port_mirror(unsigned char type);

/*	Set Port Mirror Mode
 *	mode:	0 - disable mirror
 *			1 - mirror egress packets only
 *			2 - mirror ingress packets only
 *			3 - mirror both egress & ingress packets
 */
#define MIRROR_DISABLE		0
#define MIRROR_EGRESS		1
#define MIRROR_INGRESS		2
#define MIRROR_BOTH			3
void port_set_port_mirror_mode(unsigned char mode);
unsigned char port_get_port_mirror_mode(void);

/*	IGMP Non associate enable 
 *	enabled:	1-enable	0-disable
 */
void port_set_non_associate_enable(unsigned char enabled);
unsigned char port_get_non_associate_enable(void);

/*	Set Non associate ports(Port Excluding)
 *	port_num:	bit# set to 1 - set port#
 *							0 - unset port#
 */
void port_set_non_associate(unsigned long port_num);
unsigned long port_get_non_associate(void);

/*	Set rate control for this port
 *	port_num:	physical port number(0~23)
 *	dir:		1-TX	egress
 *				0-RX	ingress
 *	bandwidth:	0~255(units)
 */
#define BANDWIDTH_RX			0
#define BANDWIDTH_TX			1
void port_set_bandwidth(unsigned char port_num,unsigned char dir,unsigned char bandwidth);
unsigned char port_get_bandwidth(unsigned char port_num,unsigned char dir);

/*	Set rate control unit value
 *	func:	1- 1 unit is 512Kbps
 *			0- 1 unit is 32Kbps
 */
#define BANDWIDTH_LOW			0
#define BANDWIDTH_HIGH			1
void port_set_bandwidth_func(unsigned char func);
unsigned char port_get_bandwidth_func(void);

/* Set Counter enable - Affects all ports
 *	enable		1-enable counter	0-disable counter
 */
#define COUNTER_ENABLE			1
#define COUNTER_DISABLE			0
void port_set_counter_enable(unsigned char enabled);
unsigned char port_get_counter_enable(void);

/* Set Counter Mode - Affects all ports
 *	mode:	1-Counter Method=1	0-Counter Method=0
 */
#define COUNTER_MODE0			0//affects 0x01[8];
#define COUNTER_MODE1			1
void port_set_counter_mode(unsigned char mode);
unsigned char port_get_counter_mode(void);

/*	Set Counter Select for this port
 *	port_num:	physical port number(0~23)
 *	select:		0-Counter Selection=0	1-Counter Selection=1
 */
/*	Counter Method & Selection Combination
 *		{Method,Selection}		Counter0			Counter1
 *			0		0			rx packets count	tx packets count
 *			0		1			tx packets count	collision count
 *			1		0			rx packets count	packets drop count(mac)
 *			1		1			rx packets count	CRC error packets count
 */
#define COUNTER_SELECT0			0
#define COUNTER_SELECT1			1
void port_set_counter_select(unsigned char port_num,unsigned char select);
unsigned char port_get_counter_select(unsigned char port_num);

/*	Set WAN filter select for this port
 *	port_num:	physical port number(0~23)
 *	enabled:	0-port not selected	1-port selected
 */
void port_set_wanfilter(unsigned char port_num,unsigned char enabled);
unsigned char port_get_wanfilter(unsigned char port_num);
void port_set_wanfilter_all(unsigned long ports);
unsigned long port_get_wanfilter_all(void);

/* Set Wanfilter Mode - Affects all ports
 *	mode:	1-positive filter list	0-negative list
 */
#define WANFILTER_POSITIVE_LIST	1
#define WANFILTER_NEGATIVE_LIST	0
void port_set_wanfilter_mode(unsigned char mode);
unsigned char port_get_wanfilter_mode(void);

/*	Set WAN filter enable for all ports
 *	enabled:		0-WAN filter disable	1-WAN filter enable
 */
void port_set_wanfilter_enable(unsigned char enabled);
unsigned char port_get_wanfilter_enable(void);

/*	Set WAN filter protocol to list
 *	idx:		protocol index number(0~22)
 *	enabled:		0-WAN filter select	1-WAN filter select
 */
void port_set_wanfilter_protocol(unsigned char idx,unsigned char enabled);
unsigned char port_get_wanfilter_protocol(unsigned char idx);
void port_set_wanfilter_protocol_all(unsigned long protocols);
unsigned long port_get_wanfilter_protocol_all(void);


/*	Get Port Status for this port
 *	port_num:	physical port number(0~23)
 */
unsigned char	port_get_status(unsigned char port_num);


/*	Get Port Status for this port
 *	port_num:	physical port number(0~1)={24, 25}
 */
unsigned char	port_get_status_GIGA(unsigned char port_num);

/*	Get Port link Status for this port
 *	port_num:	physical port number(0~25}
 */
unsigned char	port_get_link(unsigned char port_num);

/*	Get Port link Status for fiber ports(from PCS Register)
 *	port_num:	physical port number(0, 1)=(24, 25)
 */
unsigned char	port_get_link_fiber(unsigned char port_num);

/*	Get Port Status of each case for this port
 *	port_num:	physical port number(0~23)
 *	item:	asymmetric pause	1: Enable asymmetric pause; 0: Disable asymmetric pause
 *			flow_ctrl			1: Enable flow control; 0: Disable flow control
 *			duplex				1: Full duplex; 0: Half duplex
 *			speed				1: 100 Mbps; 0: 10 Mbps
 *			link				1: Link up; 0: Link down
 */
/*
#define	PORT_STATUS_LINK		0
#define	PORT_STATUS_SPEED		1
#define	PORT_STATUS_DUPLEX		2
#define	PORT_STATUS_FLOW_CTRL	3
#define	PORT_STATUS_PAUSE		4
unsigned char	port_get_status_item(unsigned char port_num, unsigned char item);
*/

/*	Get Port Counter for this port
 *	port_num:	physical port number(0~23)
 *	which:		1-Counter 1		0-Counter 0
 */
unsigned long port_get_counter(unsigned char port_num,unsigned char which);

// clear counter value for all ports
void port_clear_counter(void);

/*	Set Force Link for this port
 *	Force link function will keep this port active regardless of the link status
 *	port_num:	physical port number(24~26)
 *	enabled:	1-enabled	0-disabled
 */
void port_set_force_link(unsigned char port_num, unsigned char enabled);
unsigned char port_get_force_link(unsigned char port_num);
//========================================================================================
// STP
//========================================================================================
#define STP_FUNC_ENABLE			0x1


/*	Set STP function enable 
 *	enabled:	0-drop	1-forward STP frames
 */
//deprecated - use security_set_l2l3_func(unsigned char idx,unsigned char func) instead
//void stp_set_enable(unsigned char enabled);
//unsigned char stp_get_enable(void);

/*	Set BPDU broadcast enable
 *	enabled:	0-do not broadcast	1-broadcast all BPDU frames
 */
void set_bpdu_bcast(unsigned char enabled);
unsigned char get_bpdu_bcast(void);

/*	Set CPU interface mode 
 *	mode:	0-MII mode	1-Reverse MII mode
 */
#define CPU_IF_RMII		1
#define CPU_IF_MII		0
void set_cpu_interface_mode(unsigned char mode);
unsigned char get_cpu_interface_mode(void);
/*	Set CPU special tag recognization enable
 *	enabled:	0-disable	1-enable CPU special tag recognization
 */
void set_special_tag_enable(unsigned char enabled);
unsigned char get_special_tag_enable(void);

/*	Set port 25 as CPU port enable
 *	enabled:	0-disable	1-enable port 25 as CPU port
 */
void set_cpu_mode_enable(unsigned char enabled);
unsigned char get_cpu_mode_enable(void);

/*	Set WAN filter select for this port
 *	port_num:	physical port number(0~23)
 *	state:		0-Discard	1-Block		2-Learning	3-Learning	4-Forward
 */
#define PORT_STATE_DISCARD		0x0
#define PORT_STATE_BLOCK		0x1
#define PORT_STATE_LISTENING	0x2
#define PORT_STATE_LEARNING		0x3
#define PORT_STATE_FORWARD		0x4
void stp_set_port_state(unsigned char port_num,unsigned char state);
unsigned char stp_get_port_state(unsigned char port_num);


//========================================================================================
// TRUNK
//========================================================================================
#define MAX_TRUNK_GROUP_NUM		3

struct _trunk_setting
{
	/*
	 * bit 0,1:	0-Port ID	1-SA	2-DA	3-SA^DA
	 */	
	unsigned char	func;
	unsigned char member[MAX_TRUNK_GROUP_NUM];
};

/*	Set Trunk group member
 *	idx:	0~2,support 3 trunk groups
 *	member:	P00 ~ p03 are the same trunk group and can be any combination.
 *			bit [3:0] : trunk configuration for port 0
 *			4'b0000: the port is not in the trunk
 *			4'bxxx1: pass the packet with ID = 0
 *			4'bxx1x: pass the packet with ID = 1
 *			4'bx1xx: pass the packet with ID = 2
 *			4'b1xxx: pass the packet with ID = 3
 *			Bit[7:4] : trunk configuration for port 01
 *			Bit[11:8] : trunk configuration for port 02
 *			Bit[15:12] : trunk configuration for port 03
 *	Note:	In a trunk group, the configuration should be ORed to
 *			4'b1111 and no more than one port has the same configuration bit
 */
void trunk_set_group_member(unsigned char idx,unsigned short member);
unsigned short trunk_get_group_member(unsigned char idx);

/*	Set Trunk hash function
 *	func:	0-by Port ID	1-by SA	2-by DA	3-by SA&DA
 */
#define TRUNK_HASH_PORT_ID	0x0
#define TRUNK_HASH_SA		0x1
#define TRUNK_HASH_DA		0x2
#define TRUNK_HASH_SA_DA	0x3
void trunk_set_func(unsigned char func);
unsigned char trunk_get_func(void);

/*	Set Slow Protocol enabled
 *	enabled:	0-Disable	1-Enable
 */
//depreciated - use security_set_l2l3_func(unsigned char idx,unsigned char func) instead
//void set_slow_protocol_enable(unsigned char enabled);
//unsigned char get_slow_protocol_enable(void);

void trunk_set_all(struct _trunk_setting *trunk_setting);

#define MAX_IGMP_ENTRY_NUM	32

//========================================================================================
//	IGMP
//========================================================================================
/*	Now the driver only supports hardware IGMP
 *	related functions. 
 */

struct _igmp_setting
{

	/*
	 * bit 0:	1 - enable		0 - disable
	 * bit 1:	1 - CPU mode	0 - Hardware mode	
	 * bit 2:	1 - Disable MAC 01:00:5e:00:00:xx bcast
	 * bit 3:	"Report" packets also to host
	 * bit 4:	"Leave"	packets send to router port
	 * bit 5:	1 - router port list configured by CPU only(a must if CPU mode)
	 * bit 6:	Disable "leave" function
	 * bit 7:	non-IGMP mcast packets to CPU only
	 * bit 8:	Send "Query" packets to CPU only
	 * bit 9:	Send "Report" packets to CPU only	 
	 * bit 10:	keep this bit at 0
	 */
	unsigned short	func;

	unsigned long	router_port_list;
};

/*	Set IGMP functions, please check the list above 
 *	to understand the function of each bit
 */
void igmp_set_func(unsigned short func);
unsigned short igmp_get_func(void);

/*	2009.06.18	Kevin Wang.
 *	Though the driver already implements router port set function
 *	It won't be used under hardware IGMP mode. IGMP member set
 *	functions needs further spec so it's not implemented yet.
 */
/*	Set router ports
 *	port_num:	bit# set to 1 - set port#
 *							0 - unset port#
 */
void igmp_set_router_port(unsigned long router_ports);
unsigned long igmp_get_router_port(void);

/*	IGMP snooping function enable 
 *	enabled:	1-enable	0-disable
 */
void igmp_set_enabled(unsigned char enabled);
unsigned char igmp_get_enabled(void);
//void igmp_set_member_port(unsigned char idx,unsigned long member_port,unsigned short dest_addr);
void igmp_set_all(struct _igmp_setting *igmp_setting);

/*	Block broadcast frames to CPU port enable
 *	enabled:	1-enable blocking	0-disable blocking
 */
void set_block_bcast_to_cpu(unsigned char enabled);
unsigned char get_block_bcast_to_cpu(void);

/*	Pass all IPv4 packets when block bcast frames to CPU
 *	pass:	1-enable pass	0-disable pass
 */
void set_pass_ipv4_to_cpu(unsigned char enabled);
unsigned char get_pass_ipv4_to_cpu(void);

//========================================================================================
//	MISC
//========================================================================================
/*	No plan to implement yet */
/*
void misc_set_aging(unsigned char type,unsigned long time);
void misc_set_arp_icmp_storm_ctrl(unsigned char type,unsigned char enabled);
*/

//========================================================================================
// LUT
//========================================================================================
//#define LUT_TWICE_BUG		//flaze test for LUT read twice bug
//#define LUT_MAC_DEBUG		//flaze test
//#define LUT_IP_DEBUG		//flaze test
//#define LUT_LOCKMAC_DEBUG	//flaze test

#define MAX_MAC_LUT_ENTRY 4096
#define MAX_IP_LUT_ENTRY  32

struct _lut_setting
{
	unsigned char lut_mode;
};

/*	LUT MAC entry
 *	aging:		4'b1111 for static.
 *				4'b0000 for invalid.
 *				4'b0001 ~ 1110 for aging.
 *				Write 4'b1110 if aging is needed.
 *	port_num:	5 bits port - which port should be routing to
 *	mac_addr:	35 bits MAC Address - the combination is {mac[47:41], mac[39:12]}
 *	sa:			for Source MAC drop function. If 1'b1, source MAC match will be drop.		
 */
struct _lut_mac_entry{
	unsigned char aging;
	unsigned char port_num;
	unsigned char mac_addr[6];
	unsigned char sa;
};

/*	LUT IGMP entry
 *	aging:		4'b1111 for static.
 *				4'b0000 for invalid.
 *				4'b0001 ~ 1110 for aging.
 *				Write 4'b1110 if aging is needed.
 *	cpu:		if this bit is 1'b1, only CPU and aging function will set this entry
 *				(aging bits should not be 4'b0000).
 *	member:		27 bits Multicast member - the membership of the multicast group.
 *	mac:		12 bits MAC Address - the combination is mac[23:12]  (mac[47:24] is 01-00-5e, mac[23] will be 1'b0)
 */
struct _lut_igmp_entry{
	unsigned char aging;
	unsigned char cpu;
	unsigned long member;
	unsigned char mac_addr[6];
};
/*	LUT IP entry
 *	aging:		4'b1111 for static.
 *				(The IP entry should be configured as a static address by writing the aging field with "1111")
 *				4'b0000 for invalid.
 *				4'b0001 ~ 1110 for aging.
 *				Write 4'b1110 if aging is needed.
 *	port_num:	5 bits source port - the source port of the received packets.
 *				1826 ip entry support 3 source ports.
 *	ip_addr:	24 bits ip address.		
 */
struct _lut_ip_entry{
	unsigned char aging;
	unsigned char port_num[3];
	unsigned char ip_addr[4];
};
/*	LUT Control Register
 *	r_w1:		1 - write
 *				0 - read
 *	r_w2:		data indicator
 *				1 - write
 *				0 - read
 *	enable:		1 - enable
 *				0 - disable
 *	complete:	1 - command complete
 *				0 - not yet
 */
 /*
struct _lut_ctrl{
	unsigned int r_w1:1;
	unsigned int r_w2:1;
	unsigned int enable:1;
	unsigned int complete:1;
};
*/ 
/*
typedef union _lut_entry
{    
    //be careful about endian problem.
    struct _mac_entry{
        unsigned int mac0H:3;
        unsigned int sa:1;
        unsigned int port_num:5;
        unsigned int type:1;
        unsigned int aging:4;
        unsigned int rsvd:2;
      
        unsigned int mac2H:4;
        unsigned int mac1:8;
        unsigned int mac0L:4;

        unsigned int mac4H:4;
        unsigned int mac3:8;
        unsigned int mac2L:4;

        unsigned int mac5:8;
        unsigned int mac4L:4;
        unsigned int command:4;
    }mac;
    struct _igmp_entry{
        unsigned int memberH:7;
        unsigned int cpu:1;
        unsigned int ip_type:1;
        unsigned int type:1;
        unsigned int aging:4;
        unsigned int rsvd:2;

        unsigned int memberM;

        unsigned int mac4H:4;
        unsigned int mac3:8;
        unsigned int memberL:4;

        unsigned int mac5:8;
        unsigned int mac4L:4;
        unsigned int command:4;
    }igmp;
    struct _ip_entry{
        unsigned int port1H:2;
        unsigned int port0:5;
        unsigned int cpu:1;
        unsigned int ip_type:1;
        unsigned int type:1;
        unsigned int aging:4;
        unsigned int rsvd:2;

        unsigned int ip0:8;
        unsigned int port2:5;
        unsigned int port1L:3;

        unsigned int ip2:8;
        unsigned int ip1:8;

        unsigned int ip3:8;
        unsigned int ip2L:4;
        unsigned int command:4;
    }ip;
    struct _lut_reg{
        unsigned int data2:16;
        unsigned int data1:16;
        unsigned int data0:16;
		    unsigned int ctrl:16;
    }reg;
}lut_entry;
*/
/*	Hash algorithm selection
 *	sel:	1 - Direct map base, using the lowest 12-bit.
 *			0 - CRC map base
*/
#define LUT_HASH_DIRECT	1
#define LUT_HASH_CRC	0
void lut_set_hash_algorithm(unsigned char sel);
unsigned char lut_get_hash_algorithm(void);

void lut_flush_table(void);
void lut_flush_port(unsigned char port);
void lut_flush_igmp(void);

/*	Scan all MAC learned at target port from LUT idx_start to idx_end
 *	port:			target port
 *	mac_idx_map:	mark the index of LUT which is learned at target port, each bit correspond to each index
 *	idx_start:		scan from this index
 *	idx_end:		scan end at this index
 */
void lut_scan_mac(unsigned char port,unsigned char *mac_idx_map,unsigned short idx_start,unsigned short idx_end);

void lut_set_mac(struct _lut_mac_entry lut_mac_entry);
struct _lut_mac_entry lut_get_mac(unsigned short index);
unsigned char lut_get_port_by_mac(unsigned char *pMac, unsigned char *port);

//struct _lut_igmp_entry lut_get_igmp(unsigned short index);

void lut_set_ip(struct _lut_ip_entry lut_ip_entry);
struct _lut_ip_entry lut_get_ip(unsigned short index);

//========================================================================================
//		SYSTEM
//========================================================================================
/*	Get IP1826C/IP1826D version ID
 *	If the value got from register 0x00 is 0x1826, means this chip is IP1826D,
 *	otherwise it's IP1826C.
 */
#define SYSTEM_CHIPID_IP1826D	0x1826
unsigned short system_get_ip1826_version(void);

void system_set_output_queue_aging(unsigned char time);
unsigned char system_get_output_queue_aging(void);

void system_set_output_queue_aging_enable(unsigned char enabled);
unsigned char system_get_output_queue_aging_enable(void);

/*	Set cpu routing
 *	The packet will be routed to the destination port based on the special tag.
 *	enable:	1 - enable
 *			0 - disable
 */
void system_set_cpu_route_enable(unsigned char enabled);
unsigned char system_get_cpu_route_enable(void);

/*	Set routing rule
 *	The switch engine will route this packet regardless of the VLAN function and port-trunking.
 *	The function works only if cpu routing is enable.
 *	enable:	1 - enable
 *			0 - disable
 *	note:	if set this function enable, special tag send packet only in specific port mode(special tag value=0x1D).
 */
void system_set_cpu_route_func(unsigned char func);
unsigned char system_get_cpu_route_func(void);

void system_set_switch_mac(unsigned char *mac);
void system_get_switch_mac(unsigned char mac[6]);

/*	Set Specific ports enabled
 *	enabled:	1:	Destination ports of packet from CPU are determined by specific member
 *				0:	Destination ports of packet from CPU are forwarded according to LUT
 *	member:		set member by port per bit, if set to 1b'1 means packet from CPU will send to this port
 *	Note:		Do not use this function in the following cases. Use VLAN instead.
 *				(a) Forward a BPDU to a specified port.
 *				(b) Forward a LACP to a specified port
 */
void system_set_specific_enabled(unsigned char enabled);
unsigned char system_get_specific_enabled(void);

void system_set_specific_member(unsigned long member);
unsigned long system_get_specific_member(void);

/*	Set special tag type
 *	tag:special tag type
 */
void system_set_special_tag(unsigned short tag);
unsigned short system_get_special_tag(void);

/*	LED testing
 */
void system_set_led_test(void);

/*	LED Clock select
 *	mode	0: 625K hz;
 *			1: 1.25Mhz
 */
void system_set_led_clock(unsigned char mode);


//========================================================================================
#endif
