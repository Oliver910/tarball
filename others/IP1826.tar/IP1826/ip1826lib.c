#include "ip1826.h"
#include "ip1826lib.h"


#ifdef USER_API
#include <string.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdio.h>
#include <linux/types.h>
#else
#include <linux/module.h>
#endif

#include <stdbool.h>

//#define MODULE_24_2P

#ifdef MODULE_24_2P
	#define MAX_PORT_NUM				26
	#define FIBER_PORT_NUM				2
#else
  #ifdef MODULE_16_2P
  	#define MAX_PORT_NUM				18
  	#define FIBER_PORT_NUM				2
  #endif
#endif


#define CPU_PORT			MAX_PORT_NUM
#define	NORMAL_PORT_NUM		(MAX_PORT_NUM-FIBER_PORT_NUM)




const char *dev_ip1826="/dev/ip1826";
#define read_reg ip1826_read_reg
#define write_reg ip1826_write_reg 

#ifdef USER_API                           
unsigned short ip1826_read_reg(unsigned char regad)
{
  int fd,retval;
  struct GeneralSetting gs;
  memset(&gs,0x0,sizeof(struct GeneralSetting));
  gs.addr=regad;
  
  if((fd=open(dev_ip1826,O_RDWR))<0)
    printf("Err: open %s failed!\n", dev_ip1826);        
  if(ioctl(fd,IP1826_READ,&gs)<0)
    printf("Err: ioctl %s failed!\n", dev_ip1826);
#ifdef USER_API_DEBUG
printf("lib:ip1826_read_reg addr=%02x data=%04x\n",gs.addr,gs.data);
#endif   
	retval = close(fd);
	if (retval < 0)
		printf("Err: close %s failed!\n", fd);          
  return gs.data;
}
void ip1826_write_reg(unsigned char regad, unsigned short Regdata)
{
  int fd,retval;
  struct GeneralSetting gs;
#ifdef USER_API_DEBUG
printf("lib:ip1826_write_reg addr=%02x data=%04x\n",regad,Regdata);
#endif
  memset(&gs,0x0,sizeof(struct GeneralSetting));
  gs.addr=regad;
  gs.data=Regdata;
  if((fd=open(dev_ip1826,O_RDWR))<0)
    printf("Err: open %s failed!\n", dev_ip1826);        
  if(ioctl(fd,IP1826_WRITE,&gs)<0)
    printf("Err: ioctl %s failed!\n", dev_ip1826);
	retval = close(fd);
	if (retval < 0)
		printf("Err: close %s failed!\n", fd);            
} 
void ip1826_test_mdio(unsigned char regad)
{
  int fd,retval;
  struct GeneralSetting gs;
  memset(&gs,0x0,sizeof(struct GeneralSetting));
  gs.addr=0xffff;
  gs.data=regad; 
  if((fd=open(dev_ip1826,O_RDWR))<0)
    printf("Err: open %s failed!\n", dev_ip1826);        
  if(ioctl(fd,IP1826_WRITE,&gs)<0)
    printf("Err: ioctl %s failed!\n", dev_ip1826);
	retval = close(fd);
	if (retval < 0)
		printf("Err: close %s failed!\n", fd);           
}
#else   
unsigned short ip1826_read_reg(unsigned char regad)
{
  return ip1826_mdio_rd(((regad)>>5)&0x1f,(regad)&0x1f);
}
void ip1826_write_reg(unsigned char regad, unsigned short Regdata)
{
  ip1826_mdio_wr(((regad)>>5)&0x1f,(regad)&0x1f,Regdata);  
}
#endif
//========================================================================================
void write_reg_common(unsigned char reg_num,unsigned char reg_start,unsigned char idx,unsigned char value)
{
	unsigned short reg_val;

	if(reg_num == 2){
		if(idx < 16)
			reg_val = read_reg(reg_start);
		else
			reg_val = read_reg((reg_start+1));
		reg_val &= ~(0x1 << (idx%16));
		reg_val |= (unsigned short)(value&0x1) << (idx%16);

		if(idx < 16)
		{	write_reg(reg_start,reg_val);	}
		else
		{	write_reg(reg_start+1,reg_val);	}
	}
	else if(reg_num == 1)
	{
		reg_val = read_reg(reg_start);
		reg_val &= ~(0x1 << idx);
		reg_val |= (unsigned short)(value&0x1) << idx;

		write_reg(reg_start,reg_val);
	}
}

unsigned char read_reg_common(unsigned char reg_num,unsigned char reg_start,unsigned char idx)
{
	unsigned short reg_val;
	
	if(reg_num==1 || idx<16)
		reg_val = read_reg(reg_start);
	else
		reg_val = read_reg(reg_start+1);
	reg_val &= (0x1<<(idx%16));
	reg_val >>= (idx%16);

	return (unsigned char)reg_val;
}

unsigned long port_bit_transfer(unsigned long ports)
{
#ifdef MODULE_24_2P
  return (ports&0x7ffffff);
#else
  return ((ports&0xffff)|((ports&0x70000)<<8));
#endif 
}
unsigned long port_bit_transfer_R(unsigned long ports)
{
#ifdef MODULE_24_2P
  return (ports&0x7ffffff);
#else
  return ((ports&0xffff)|((ports&0x7000000)>>8));
#endif 
}
unsigned char port_num_transfer(unsigned char port)
{
#ifdef MODULE_24_2P
  return port;
#else
  if(port>=NORMAL_PORT_NUM)
    return (port+8);
  else
    return port;
#endif
}
unsigned char port_num_transfer_R(unsigned char port)
{
#ifdef MODULE_24_2P
  return port;
#else
  if(port>=NORMAL_PORT_NUM)
    return (port-8);
  else
    return port;
#endif
}
unsigned short crc_16(unsigned char *mac)
{
	int i,j;
	unsigned short crc_ok=0;
	bool d[24],c[16],n[16];
	unsigned char NC[2],CRC[2];//,D02=0,D01=0,D00=0;
	for(i=0;i<2;i++)
	{
		for(j=0;j<24;j++)
		{
			d[j]=((mac[i*3+j/8]>>(7-(j%8)))&0x1);
		}
		if(i==0)
		{	NC[1]=0x0f; NC[0]=0xff;	}
		else
		{	NC[1]=CRC[1]; NC[0]=CRC[0];	}
		for(j=0;j<16;j++)
		{
			n[j]=((NC[j/8]>>j%8)&0x1);
		}
		c[0] = d[23]^d[22]^d[17]^d[16]^d[15]^d[14]^d[13]^d[12]^d[11]^d[8]^d[7]^d[6]^d[5]^d[4]^d[3]^d[2]^d[1]^d[0]^\
			n[0]^n[1]^n[2]^n[3]^n[4]^n[5]^n[10]^n[11];
		c[1] = d[22]^d[18]^d[11]^d[9]^d[0]^n[6]^n[10];
		c[2] = d[22]^d[19]^d[17]^d[16]^d[15]^d[14]^d[13]^d[11]^d[10]^d[8]^d[7]^d[6]^d[5]^d[4]^d[3]^d[2]^d[0]^\
			n[1]^n[2]^n[3]^n[4]^n[5]^n[7]^n[10];
		c[3] = d[22]^d[20]^d[18]^d[13]^d[9]^d[2]^d[0]^n[1]^n[6]^n[8]^n[10];
		c[4] = d[23]^d[21]^d[19]^d[14]^d[10]^d[3]^d[1]^n[2]^n[7]^n[9]^n[11];
		c[5] = d[22]^d[20]^d[15]^d[11]^d[4]^d[2]^n[3]^n[8]^n[10];
		c[6] = d[23]^d[21]^d[16]^d[12]^d[5]^d[3]^n[0]^n[4]^n[9]^n[11];
		c[7] = d[22]^d[17]^d[13]^d[6]^d[4]^n[1]^n[5]^n[10];
		c[8] = d[23]^d[18]^d[14]^d[7]^d[5]^n[2]^n[6]^n[11];
		c[9] = d[19]^d[15]^d[8]^d[6]^n[3]^n[7];
		c[10] = d[20]^d[16]^d[9]^d[7]^n[4]^n[8];
		c[11] = d[23]^d[22]^d[21]^d[16]^d[15]^d[14]^d[13]^d[12]^d[11]^d[10]^d[7]^d[6]^d[5]^d[4]^d[3]^d[2]^d[1]^d[0]^\
			n[0]^n[1]^n[2]^n[3]^n[4]^n[9]^n[10]^n[11];

		CRC[0]=CRC[1]=0;
		for(j=0;j<16;j++)
		{
			CRC[j/8]|=(c[j]<<(j)%8);
		}
		CRC[1] &= 0x0f;
	}
	crc_ok=CRC[1];
	crc_ok<<=8;
	crc_ok|=CRC[0];
	
	return crc_ok;
}
//========================================================================================
//		VLAN
//========================================================================================
void vlan_set_vid(unsigned char idx,unsigned short vid)
{
	write_reg(IP1826_VLAN_VID+idx,vid);
}

unsigned short vlan_get_vid(unsigned char idx)
{
	return read_reg(IP1826_VLAN_VID+idx);
}

void vlan_set_across_vlan(unsigned char enabled)
{
	write_reg_common(1,IP1826_ARL_OPERATION_SETTING,7,enabled);
}

unsigned char vlan_get_across_vlan(void)
{
	return read_reg_common(1,IP1826_ARL_OPERATION_SETTING,7);
}

void vlan_set_mode(unsigned char vlan_mode)
{			
	write_reg_common(1,IP1826_ARL_OPERATION_SETTING,6,vlan_mode);	
}

unsigned char vlan_get_mode(void)
{
	return read_reg_common(1,IP1826_ARL_OPERATION_SETTING,6);
}

void vlan_set_tag_handling(unsigned char mode)
{
	unsigned short reg_val;

	reg_val = read_reg(IP1826_ARL_OPERATION_SETTING);
	reg_val &= ~((unsigned short)0x3<<14);
	reg_val |= ((unsigned short)mode&0x3) << 14;
	write_reg(IP1826_ARL_OPERATION_SETTING,reg_val);
}
unsigned char vlan_get_tag_handling(void)
{
	unsigned short reg_val;
	reg_val = read_reg(IP1826_ARL_OPERATION_SETTING);
	reg_val >>=14;
	return (unsigned char)reg_val;
}

void vlan_set_member(unsigned char idx,unsigned long member_port)
{
  member_port = port_bit_transfer(member_port);
	vlan_set_tag_handling(VLAN_TAG_RULE_MEMBER);
	write_reg(IP1826_VLAN_MEMBER_LOW(idx),(unsigned short)(member_port&0xffff));
	write_reg(IP1826_VLAN_MEMBER_HIGH(idx),(unsigned short)(member_port>>16));
}

unsigned long vlan_get_member(unsigned char idx)
{
	unsigned long member_port;

	vlan_set_tag_handling(VLAN_TAG_RULE_MEMBER);
	member_port = read_reg(IP1826_VLAN_MEMBER_LOW(idx));
	member_port |= (unsigned long)read_reg(IP1826_VLAN_MEMBER_HIGH(idx))<<16;

	return port_bit_transfer_R(member_port);
}

void vlan_set_tag_mode(unsigned char mode)
{
	write_reg_common(1,IP1826_ARL_OPERATION_SETTING,13,mode);
}
unsigned char vlan_get_tag_mode(void)
{
	return read_reg_common(1,IP1826_ARL_OPERATION_SETTING,13);
}

void vlan_set_addtag(unsigned long addtag_port)
{
  addtag_port = port_bit_transfer(addtag_port);
	write_reg(IP1826_VLAN_TAG_ADD_00,(unsigned short)(addtag_port&0xffff));
	write_reg(IP1826_VLAN_TAG_ADD_01,(unsigned short)(addtag_port>>16));
}
unsigned long vlan_get_addtag(void)
{
	unsigned long addtag_port = 0;

	addtag_port = read_reg(IP1826_VLAN_TAG_ADD_00);
	addtag_port |= (unsigned long)read_reg(IP1826_VLAN_TAG_ADD_01)<<16;

	return port_bit_transfer_R(addtag_port);
}

void vlan_set_rmvtag(unsigned long rmvtag_port)
{
  rmvtag_port = port_bit_transfer(rmvtag_port);
	write_reg(IP1826_VLAN_TAG_RMV_00,(unsigned short)(rmvtag_port&0xffff));
	write_reg(IP1826_VLAN_TAG_RMV_01,(unsigned short)(rmvtag_port>>16));
}

unsigned long vlan_get_rmvtag(void)
{
	unsigned long rmvtag_port = 0;

	rmvtag_port = read_reg(IP1826_VLAN_TAG_RMV_00);
	rmvtag_port |= (unsigned long)read_reg(IP1826_VLAN_TAG_RMV_01)<<16;

	return port_bit_transfer_R(rmvtag_port);
}

void vlan_set_addtag_vid(unsigned char idx, unsigned long addtag_port)
{
  addtag_port = port_bit_transfer(addtag_port);
	vlan_set_tag_handling(VLAN_TAG_RULE_ADDTAG);
	write_reg(IP1826_VLAN_MEMBER_LOW(idx),(unsigned short)(addtag_port&0xffff));
	write_reg(IP1826_VLAN_MEMBER_HIGH(idx),(unsigned short)(addtag_port>>16));
	vlan_set_tag_handling(VLAN_TAG_RULE_MEMBER);	//recovery vlan tag mode
}

unsigned long vlan_get_addtag_vid(unsigned char idx)
{
	unsigned long addtag_port = 0;

	vlan_set_tag_handling(VLAN_TAG_RULE_ADDTAG);
	addtag_port = read_reg(IP1826_VLAN_MEMBER_LOW(idx));
	addtag_port |= (unsigned long)read_reg(IP1826_VLAN_MEMBER_HIGH(idx))<<16;
	vlan_set_tag_handling(VLAN_TAG_RULE_MEMBER);	//recovery vlan tag mode

	return port_bit_transfer_R(addtag_port);
}

void vlan_set_rmvtag_vid(unsigned char idx, unsigned long rmvtag_port)
{
  rmvtag_port = port_bit_transfer(rmvtag_port);
	vlan_set_tag_handling(VLAN_TAG_RULE_RMVTAG);
	write_reg(IP1826_VLAN_MEMBER_LOW(idx),(unsigned short)(rmvtag_port&0xffff));
	write_reg(IP1826_VLAN_MEMBER_HIGH(idx),(unsigned short)(rmvtag_port>>16));
	vlan_set_tag_handling(VLAN_TAG_RULE_MEMBER);	//recovery vlan tag mode
}

unsigned long vlan_get_rmvtag_vid(unsigned char idx)
{
	unsigned long rmvtag_port = 0;

	vlan_set_tag_handling(VLAN_TAG_RULE_RMVTAG);
	rmvtag_port = read_reg(IP1826_VLAN_MEMBER_LOW(idx));
	rmvtag_port |= (unsigned long)read_reg(IP1826_VLAN_MEMBER_HIGH(idx))<<16;
	vlan_set_tag_handling(VLAN_TAG_RULE_MEMBER);	//recovery vlan tag mode
	
	return port_bit_transfer_R(rmvtag_port);
}

void vlan_set_pvid(unsigned char port_num,unsigned char pvid)
{
	unsigned short reg_val;
  port_num = port_num_transfer(port_num);
	reg_val = read_reg(IP1826_VLAN_PVID+(unsigned short)(port_num/3));
	reg_val &= ~((unsigned short)0x1f<<5*(port_num%3));
	reg_val |= (unsigned short)pvid << (5*(port_num%3));
	write_reg(IP1826_VLAN_PVID+(unsigned short)(port_num/3),reg_val);
}

unsigned char vlan_get_pvid(unsigned char port_num)
{
	unsigned short reg_val;
  port_num = port_num_transfer(port_num);
	reg_val = read_reg(IP1826_VLAN_PVID+(unsigned short)(port_num/3));
	reg_val >>= 5*(port_num%3);
	reg_val &= 0x1f;

	return (unsigned char)reg_val;
}

void vlan_set_uplink_enable(unsigned char enabled)
{
	write_reg_common(1,IP1826_ARL_OPERATION_SETTING,8,enabled);
}

unsigned char vlan_get_uplink_enable(void)
{
	return read_reg_common(1,IP1826_ARL_OPERATION_SETTING,8);
}

void vlan_set_uplink(unsigned long uplink)
{
  uplink = port_bit_transfer(uplink);
	write_reg(IP1826_VLAN_UPLINK_00,(unsigned short)(uplink&0xffff));
	write_reg(IP1826_VLAN_UPLINK_01,(unsigned short)(uplink>>16));
}

unsigned long vlan_get_uplink(void)
{
	unsigned long uplink;

	uplink = read_reg(IP1826_VLAN_UPLINK_00);
	uplink |= (unsigned long)read_reg(IP1826_VLAN_UPLINK_01)<<16;

	return port_bit_transfer_R(uplink);
}

//void vlan_set_all(struct _vlan_setting *vlan_setting){}
//========================================================================================
//		QOS
//========================================================================================
void qos_set_schedule_mode(unsigned char mode)
{
	unsigned short tmp_mode;
	tmp_mode = read_reg(IP1826_OUT_QUEUE_SCHEDULE_MODE)&(~0x3);
	tmp_mode |= (unsigned short)mode;
	write_reg(IP1826_OUT_QUEUE_SCHEDULE_MODE,tmp_mode);
}

unsigned char qos_get_schedule_mode(void)
{
	return read_reg(IP1826_OUT_QUEUE_SCHEDULE_MODE)&0x3;
}

void qos_set_queue_weight(unsigned char mode, unsigned char weight)
{
	unsigned short tmp_weight;
	if(mode == QOS_QUEUE_LOW)
	{
		tmp_weight = read_reg(IP1826_OUT_QUEUE_SCHEDULE_MODE)&(~0x1C);
		tmp_weight |= (unsigned short)(weight<<2);
	}
	else
	{	
		tmp_weight = read_reg(IP1826_OUT_QUEUE_SCHEDULE_MODE)&(~0xE0);
		tmp_weight |= (unsigned short)(weight<<5);
	}
	write_reg(IP1826_OUT_QUEUE_SCHEDULE_MODE,tmp_weight);
}

unsigned char qos_get_queue_weight(unsigned char mode)
{
	unsigned char weight;
	weight = (unsigned char)read_reg(IP1826_OUT_QUEUE_SCHEDULE_MODE);
	if(mode == QOS_QUEUE_LOW)
	{	weight >>= 2;	}
	else
	{	weight >>= 5;	}
	
	weight &= 0x07;
	return weight;
}

void qos_set_port_enable(unsigned char port_num,unsigned char enabled)
{
  port_num = port_num_transfer(port_num);
	write_reg_common(2,IP1826_PORT_BASE_PRI,port_num,enabled);	
}

unsigned char qos_get_port_enable(unsigned char port_num)
{
  port_num = port_num_transfer(port_num);
	return read_reg_common(2,IP1826_PORT_BASE_PRI,port_num);
}

void qos_set_port(unsigned long port)
{
  port = port_bit_transfer(port);
	write_reg(IP1826_PORT_BASE_PRI_01,(unsigned short)(port&0xffff));
	write_reg(IP1826_PORT_BASE_PRI_02,(unsigned short)(port>>16));
}

unsigned long qos_get_port(void)
{
	unsigned long port;
	port = read_reg(IP1826_PORT_BASE_PRI_01);
	port |= (unsigned long)read_reg(IP1826_PORT_BASE_PRI_02)<<16;
	return port_bit_transfer_R(port);
}

void qos_set_tag_enable(unsigned char port_num,unsigned char enabled)
{
  port_num = port_num_transfer(port_num);
	write_reg_common(2,IP1826_VLAN_BASE_PRI,port_num,enabled);
}

unsigned char qos_get_tag_enable(unsigned char port_num)
{
  port_num = port_num_transfer(port_num);
	return read_reg_common(2,IP1826_VLAN_BASE_PRI,port_num);
}

void qos_set_tag(unsigned long port)
{
  port = port_bit_transfer(port);
	write_reg(IP1826_VLAN_BASE_PRI_01,(unsigned short)(port&0xffff));
	write_reg(IP1826_VLAN_BASE_PRI_02,(unsigned short)(port>>16));
}

unsigned long qos_get_tag(void)
{
	unsigned long port;
	port = read_reg(IP1826_VLAN_BASE_PRI_01);
	port |= (unsigned long)read_reg(IP1826_VLAN_BASE_PRI_02)<<16;
	return port_bit_transfer_R(port);
}

void qos_set_cos_enable(unsigned char port_num,unsigned char enabled)
{
  port_num = port_num_transfer(port_num);
	write_reg_common(2,IP1826_IPDS_BASE_PRI,port_num,enabled);		
}

unsigned char qos_get_cos_enable(unsigned char port_num)
{
  port_num = port_num_transfer(port_num);
	return read_reg_common(2,IP1826_IPDS_BASE_PRI,port_num);
}

void qos_set_cos(unsigned long port)
{
  port = port_bit_transfer(port);
	write_reg(IP1826_IPDS_BASE_PRI_01,(unsigned short)(port&0xffff));
	write_reg(IP1826_IPDS_BASE_PRI_02,(unsigned short)(port>>16));
}

unsigned long qos_get_cos(void)
{
	unsigned long port;
	port = read_reg(IP1826_IPDS_BASE_PRI_01);
	port |= (unsigned long)read_reg(IP1826_IPDS_BASE_PRI_02)<<16;
	return port_bit_transfer_R(port);
}

void set_protocol_func(unsigned char idx,unsigned char func)
{
	unsigned short reg_val;
	reg_val = read_reg(IP1826_TCP_UDP_PORTBASE_PRIORITY+(idx/8));
	reg_val &= ~((unsigned short)0x3 << ((idx%8)*2));
	reg_val |= (unsigned short)func << ((idx%8)*2);
	write_reg(IP1826_TCP_UDP_PORTBASE_PRIORITY+(idx/8),reg_val);
}

unsigned char get_protocol_func(unsigned char idx)
{
	unsigned short reg_val;
	reg_val = read_reg(IP1826_TCP_UDP_PORTBASE_PRIORITY+(idx/8));
	reg_val >>= ((idx%8)*2);
	reg_val &= 0x3;
	return (unsigned char)reg_val;
}

void set_user_protocol_port(unsigned char idx,unsigned short port)
{			
	write_reg(IP1826_USER_DEFINE_TCP_PORT+idx,port);
}

unsigned short get_user_protocol_port(unsigned char idx)
{
	return read_reg(IP1826_USER_DEFINE_TCP_PORT+idx);
}

void set_user_protocol_mask(unsigned char idx,unsigned char mask)
{
	unsigned short tmp_mask;
	tmp_mask = read_reg(IP1826_USER_DEFINE_TCP_MASK+(idx/2));
	tmp_mask &= (unsigned short)0xff << ((idx%2)?0:8);
	tmp_mask |= (unsigned short)mask << ((idx%2)*8);
	write_reg(IP1826_USER_DEFINE_TCP_MASK+(idx/2),tmp_mask);
}

unsigned char get_user_protocol_mask(unsigned char idx)
{
	unsigned short reg_val;
	reg_val = read_reg(IP1826_USER_DEFINE_TCP_MASK+(idx/2));
	reg_val >>= ((idx%2)*8);
	return (unsigned char)reg_val;
}

void qos_set_cpu_forward(unsigned char enabled)
{
	unsigned short reg_val;
	reg_val = read_reg(IP1826_GENERAL_MAC_OPERATUON_BEHAVIOR)&(~0x0080);
	reg_val |= (unsigned short)enabled << 7;
	write_reg(IP1826_GENERAL_MAC_OPERATUON_BEHAVIOR,reg_val);
}

unsigned char qos_get_cpu_forward(void)
{
	return (read_reg(IP1826_GENERAL_MAC_OPERATUON_BEHAVIOR)>>7)&0x1;
}

void qos_set_low_priority(unsigned char enabled)
{
	unsigned short reg_val;
	reg_val = read_reg(IP1826_GENERAL_MAC_OPERATUON_BEHAVIOR)&(~0x100);
	reg_val |= (unsigned short)enabled << 8;
	write_reg(IP1826_GENERAL_MAC_OPERATUON_BEHAVIOR,reg_val);
}

unsigned char qos_get_low_priority(void)
{
	return (read_reg(IP1826_GENERAL_MAC_OPERATUON_BEHAVIOR)>>8)&0x1;
}

void qos_set_all(struct _qos_setting *qos_setting)
{
	unsigned short i;	
	qos_set_schedule_mode(qos_setting->schedule_mode);
	qos_set_queue_weight(QOS_QUEUE_LOW,	qos_setting->queue_low_WRR_weight);
	qos_set_queue_weight(QOS_QUEUE_HIGH,qos_setting->queue_high_WRR_weight);
	qos_set_port(qos_setting->port_enable);
	qos_set_tag(qos_setting->tag_enable);
	qos_set_cos(qos_setting->cos_enable);
	for(i=0;i<MAX_SYS_PROTOCOL_NUM;i++)
	{
		set_protocol_func(i, qos_setting->protocol_func[i]);
	}
	for(i=0;i<MAX_USER_PROTOCOL_NUM;i++)
	{
		set_user_protocol_port(i, qos_setting->user_protocol_port[i].port);
		set_user_protocol_mask(i, qos_setting->user_protocol_port[i].mask);
	}
	qos_set_low_priority(qos_setting->low_priority);
}
//========================================================================================
//		SECURITY
//========================================================================================
void security_set_mac_enable(unsigned char port_num,unsigned char enabled)
{
	port_set_learning(port_num,enabled?0:1);
}

unsigned char security_get_mac_enabled(unsigned char port_num)
{
	return port_get_learning(port_num)?0:1;
}

void security_set_mac_func(unsigned char func)
{
	unsigned short reg_val;

	reg_val = read_reg(IP1826_SECURITY_CONFIG);
	reg_val &= ~((unsigned short)0x3);
	reg_val |= (unsigned short)func&0x3;
	write_reg(IP1826_SECURITY_CONFIG,reg_val);
}

unsigned char security_get_mac_func(void)
{
	unsigned short reg_val;

	reg_val = read_reg(IP1826_SECURITY_CONFIG);
	reg_val &= 0x3;

	return (unsigned char)reg_val;
}

void security_set_auth_enable(unsigned char port_num,unsigned char enabled)
{
  port_num = port_num_transfer(port_num);
	write_reg_common(2,IP1826_SECURITY_802_1X_ENABLE,port_num,enabled);	
}

unsigned char security_get_auth_enable(unsigned char port_num)
{
  port_num = port_num_transfer(port_num);
	return read_reg_common(2,IP1826_SECURITY_802_1X_ENABLE,port_num);	
}

void security_set_auth(unsigned long port)
{
  port = port_bit_transfer(port);
	write_reg(IP1826_SECURITY_802_1X_ENABLE_0,(unsigned short)(port&0xffff));
	write_reg(IP1826_SECURITY_802_1X_ENABLE_1,(unsigned short)(port>>16));
}
unsigned long security_get_auth(void)
{
	unsigned long port;
	port = read_reg(IP1826_SECURITY_802_1X_ENABLE_0);
	port |= (unsigned long)read_reg(IP1826_SECURITY_802_1X_ENABLE_1)<<16;
	return port_bit_transfer_R(port);
}

void security_set_auth_func(unsigned char func)
{	
	write_reg_common(1,IP1826_ETHERNET_PROTOCOL_FRAME_CAPTURE,2,func);	
}

unsigned char security_get_auth_func(void)
{	
	return read_reg_common(1,IP1826_ETHERNET_PROTOCOL_FRAME_CAPTURE,2);
}

void security_set_ip_filter_enable(unsigned char enable)
{
	write_reg_common(1,IP1826_IP_ADDRESS_SECURITY,7,enable);
}
unsigned char security_get_ip_filter_enable(void)
{
	return read_reg_common(1,IP1826_IP_ADDRESS_SECURITY,7);
}

void security_set_ip_type(unsigned char type)
{	
	write_reg_common(1,IP1826_IP_ADDRESS_SECURITY,3,type);
}
unsigned char security_get_ip_type(void)
{
	return read_reg_common(1,IP1826_IP_ADDRESS_SECURITY,3);
}

void security_set_ip_filter_mode(unsigned char mode)
{
	unsigned short reg_val;
	
	reg_val = read_reg(IP1826_IP_ADDRESS_SECURITY);
	reg_val &= ~((unsigned short)0x3);
	reg_val |= (unsigned short)mode&0x3;
	write_reg(IP1826_IP_ADDRESS_SECURITY,reg_val);
}
unsigned char security_get_ip_filter_mode(void)
{
	return (unsigned char)(read_reg(IP1826_IP_ADDRESS_SECURITY)&0x3);
}

void security_set_ip_entry_mode(unsigned char mode)
{
	write_reg_common(1,IP1826_IP_ADDRESS_SECURITY,2,mode);
}
unsigned char security_get_ip_entry_mode(void)
{
	return read_reg_common(1,IP1826_IP_ADDRESS_SECURITY,2);
}

void security_set_ip_shift(unsigned char shift)
{
	unsigned short reg_val;
	
	reg_val = read_reg(IP1826_IP_ADDRESS_SECURITY);
	reg_val &= ~((unsigned short)0x7<<4);	
	reg_val |= (unsigned short)(shift&0x7)<<4;
	write_reg(IP1826_IP_ADDRESS_SECURITY,reg_val);
}
unsigned char security_get_ip_shift(void)
{
	unsigned short reg_val;
	reg_val = read_reg(IP1826_IP_ADDRESS_SECURITY);
	reg_val >>= 4;
	reg_val &= 0x7;
	
	return (unsigned char) reg_val;
}

void security_set_l2l3_func(unsigned char idx,unsigned char func)
{
	unsigned short reg_val;
	reg_val = read_reg(IP1826_ETHERNET_PROTOCOL_FRAME_CAPTURE);
	switch(idx)
	{
	case SECURITY_ETHERNET_PROTOCOL_STP:
	case SECURITY_ETHERNET_PROTOCOL_EAPOL:
	case SECURITY_ETHERNET_PROTOCOL_LACP:
	case SECURITY_ETHERNET_PROTOCOL_GXRP:
	case SECURITY_ETHERNET_PROTOCOL_ARP:
		reg_val &= ~((unsigned short)0x1<<idx);
		reg_val |= (unsigned short)(func&0x1)<<idx;	
		break;
	case SECURITY_ETHERNET_PROTOCOL_ICMP:
	case SECURITY_ETHERNET_PROTOCOL_TCP:
	case SECURITY_ETHERNET_PROTOCOL_UDP:
	case SECURITY_ETHERNET_PROTOCOL_OSPF:
	case SECURITY_ETHERNET_PROTOCOL_OTHER:
		reg_val &= ~((unsigned short)0x3<<idx);
		reg_val |= (unsigned short)func<<idx;
		break;
	}
	write_reg(IP1826_ETHERNET_PROTOCOL_FRAME_CAPTURE,reg_val);
}

unsigned char security_get_l2l3_func(unsigned char idx)
{
	unsigned short reg_val;
	unsigned char func;

	reg_val = read_reg(IP1826_ETHERNET_PROTOCOL_FRAME_CAPTURE);

	switch(idx)
	{
	case SECURITY_ETHERNET_PROTOCOL_STP:
	case SECURITY_ETHERNET_PROTOCOL_EAPOL:
	case SECURITY_ETHERNET_PROTOCOL_LACP:
	case SECURITY_ETHERNET_PROTOCOL_GXRP:
	case SECURITY_ETHERNET_PROTOCOL_ARP:
		func = (unsigned char)((reg_val>>idx)&0x1);
		break;
	case SECURITY_ETHERNET_PROTOCOL_ICMP:
	case SECURITY_ETHERNET_PROTOCOL_TCP:
	case SECURITY_ETHERNET_PROTOCOL_UDP:
	case SECURITY_ETHERNET_PROTOCOL_OSPF:
	case SECURITY_ETHERNET_PROTOCOL_OTHER:
		func = (unsigned char)((reg_val>>idx)&0x3);
		break;
	default:
		func = 0;
		break;
	}
	return func;
}


//void security_set_all(struct _security_setting security_setting){}
//========================================================================================
// ACL
//========================================================================================

//========================================================================================
// PORT SET
//========================================================================================

void port_set_enable(unsigned char port_num,unsigned char enabled)
{
    unsigned short reg_val=0,reg_data=0;

	//for 1001 bug
	if(	port_num>=NORMAL_PORT_NUM)
	{	port_set_restart_AN(port_num);	}

  port_num = port_num_transfer(port_num);
	if(port_num<24)
	{	reg_val = port_num+8;	}
	else
	{	reg_val = port_num-23;	}
    reg_val |= (unsigned short)0x1<<15;

    write_reg(IP1826_PHY_CMD,reg_val);
    
    do{
		reg_data=read_reg(IP1826_PHY_CMD);
	}while((reg_data&((unsigned short)0x1<<13))==0);

    reg_data = read_reg(IP1826_PHY_DATA);
    reg_data &= ~((unsigned short)0x1<<11);
    reg_data |= (enabled==0)?(unsigned short)0x800:(unsigned short)0x0;

    write_reg(IP1826_PHY_DATA,reg_data);
    reg_val |= (unsigned short)0x1<<14;
    write_reg(IP1826_PHY_CMD,reg_val);
	do{
		reg_data=read_reg(IP1826_PHY_CMD);}
	while((reg_data&((unsigned short)0x1<<13))==0);

}
unsigned char port_get_enable(unsigned char port_num)
{
    unsigned short reg_val=0,reg_data=0;

    port_num = port_num_transfer(port_num);
	if(port_num<24)
	{	reg_val = port_num+8;	}
	else
	{	reg_val = port_num-23;	}
    reg_val |= (unsigned short)0x1<<15;

    write_reg(IP1826_PHY_CMD,reg_val);
    do{
		reg_data=read_reg(IP1826_PHY_CMD);
	}while((reg_data&((unsigned short)0x1<<13))==0);
    reg_data = read_reg(IP1826_PHY_DATA);

    return ((reg_data>>11)&0x1)?0x0:0x1;
}

unsigned char port_get_fiber(unsigned char port_num)
{
  port_num = port_num_transfer(port_num);
	if(port_get_link(port_num))
	{
		if(port_get_link_fiber(port_num))
		{	return PORT_BASE_FIBER;	}
		else
		{	return PORT_BASE_TP;	}
	}
	return PORT_BASE_UNLINK;
}

void port_set_fiber_AD(unsigned char enabled)
{
	write_reg_common(1,IP1826_FIBER_SETTING,7,enabled);
}

void port_set_restart_AN_fiber(unsigned char port_num)
{
    unsigned short reg_val=0,reg_data=0;
    
  port_num = port_num_transfer(port_num);	
	reg_val = (port_num%2)+1;	//PHY number
	reg_val |= (unsigned short)0x1<<12;	//PCS command trigger
//	reg_val |= (unsigned short)0x1<<15;	//PHY command trigger

    write_reg(IP1826_PHY_CMD,reg_val);
    
    do{
		reg_data=read_reg(IP1826_PHY_CMD);
	}while((reg_data&((unsigned short)0x1<<13))==0);

    reg_data = read_reg(IP1826_PHY_DATA);
    reg_data &= ~((unsigned short)0x1<<9);
    reg_data |= ((unsigned short)0x1<<9);

    write_reg(IP1826_PHY_DATA,reg_data);
    reg_val |= (unsigned short)0x1<<14;
    write_reg(IP1826_PHY_CMD,reg_val);
	do{
		reg_data=read_reg(IP1826_PHY_CMD);}
	while((reg_data&((unsigned short)0x1<<13))==0);
}

void port_set_restart_AN(unsigned char port_num)
{
    unsigned short reg_val=0,reg_data=0;

    port_num = port_num_transfer(port_num);
	if(port_num<24)
	{	reg_val = port_num+8;	}
	else
	{	reg_val = port_num-23;	}
    reg_val |= (unsigned short)0x1<<15;

    write_reg(IP1826_PHY_CMD,reg_val);
    
    do{
		reg_data=read_reg(IP1826_PHY_CMD);
	}while((reg_data&((unsigned short)0x1<<13))==0);

    reg_data = read_reg(IP1826_PHY_DATA);
    reg_data &= ~((unsigned short)0x1<<9);
    reg_data |= ((unsigned short)0x1<<9);

    write_reg(IP1826_PHY_DATA,reg_data);
    reg_val |= (unsigned short)0x1<<14;
    write_reg(IP1826_PHY_CMD,reg_val);
	do{
		reg_data=read_reg(IP1826_PHY_CMD);}
	while((reg_data&((unsigned short)0x1<<13))==0);
}

void port_set_auto_fiber(unsigned char port_num,unsigned char enabled)
{	
	unsigned short reg_val=0,reg_data=0;

  port_num = port_num_transfer(port_num);	
	reg_val = (port_num%2)+1;	//PHY number
//	reg_val |= (unsigned short)0x0<<5;		//MII register 0
	reg_val |= (unsigned short)0x1<<12;	//PCS command trigger
//	reg_val |= (unsigned short)0x1<<15;	//PHY command trigger
	
	write_reg(IP1826_PHY_CMD,reg_val);
	do{
		reg_data=read_reg(IP1826_PHY_CMD);
	}while((reg_data&((unsigned short)0x1<<13))==0);
	
	reg_data = read_reg(IP1826_PHY_DATA);
	reg_data &= ~((unsigned short)0x1<<12);
	reg_data |= (enabled==1)?((unsigned short)0x1<<12):(unsigned short)0x0;
	
	write_reg(IP1826_PHY_DATA,reg_data);
	reg_val |= (unsigned short)0x1<<14;

	write_reg(IP1826_PHY_CMD,reg_val);
	do{
		reg_data=read_reg(IP1826_PHY_CMD);
	}while((reg_data&((unsigned short)0x1<<13))==0);
	
	port_set_restart_AN_fiber(port_num);
}
unsigned char port_get_auto_fiber(unsigned char port_num)
{
	unsigned short reg_val=0,reg_data=0;

  port_num = port_num_transfer(port_num);	
	reg_val = (port_num%2)+1;	//PHY number
//	reg_val |= (unsigned short)0x0<<5;		//MII register 0
	reg_val |= (unsigned short)0x1<<12;	//PCS command trigger
//	reg_val |= (unsigned short)0x1<<15;	//PHY command trigger
	
	write_reg(IP1826_PHY_CMD,reg_val);
	do{
		reg_data=read_reg(IP1826_PHY_CMD);
	}while((reg_data&((unsigned short)0x1<<13))==0);
	
	
	reg_data = read_reg(IP1826_PHY_DATA);
	
	return ((reg_data>>12)&0x1);
}

void port_set_auto(unsigned char port_num,unsigned char enabled)
{
  port_num = port_num_transfer(port_num);
	write_reg_common(2,IP1826_AUTO_NWAY,port_num,enabled);
}

unsigned char port_get_auto(unsigned char port_num)
{
  port_num = port_num_transfer(port_num);
	return read_reg_common(2,IP1826_AUTO_NWAY,port_num);
}
unsigned char port_get_an_complete(unsigned char port_num)
{
	unsigned short reg_val=0,reg_data=0;

  port_num = port_num_transfer(port_num);	
	reg_val = port_num+8;
	reg_val |= (unsigned short)0x1<<5;
	reg_val |= (unsigned short)0x1<<15;
//	printf("set reg_val=%x in get\n",reg_val);
	write_reg(IP1826_PHY_CMD,reg_val);
	do{
		reg_data=read_reg(IP1826_PHY_CMD);
	}while((reg_data&((unsigned short)0x1<<13))==0);
//	printf("i=%d\n",i);
	reg_data = read_reg(IP1826_PHY_DATA);
//	printf("get reg_data=%x\n",reg_data);
	return ((reg_data>>5)&0x1);
}
void port_set_auto_all(unsigned long port)
{
  port = port_bit_transfer(port);
	write_reg(IP1826_AUTO_NWAY01,(unsigned short)(port&0xffff));
	write_reg(IP1826_AUTO_NWAY02,(unsigned short)(port>>16));
}

unsigned long port_get_auto_all(void)
{
	unsigned long port;
	port = read_reg(IP1826_AUTO_NWAY01);
	port |= (unsigned long)read_reg(IP1826_AUTO_NWAY02)<<16;
	return port_bit_transfer_R(port);
}
void port_set_speed(unsigned char port_num,unsigned char mode)
{
  port_num = port_num_transfer(port_num);
	if(port_num>23)
	{
		if(mode==PORT_SPEED_1000M)
		{
			write_reg_common(1,IP1826_SPEED03,port_num-24,1);
		}
		else
		{
			write_reg_common(1,IP1826_SPEED03,port_num-24,0);
			write_reg_common(2,IP1826_SPEED,port_num,mode);
		}
	}
	else
	{
		if(mode!=PORT_SPEED_10M)
		{	write_reg_common(2,IP1826_SPEED,port_num,PORT_SPEED_100M);	}
		else
		{	write_reg_common(2,IP1826_SPEED,port_num,PORT_SPEED_10M);	}
	}
}
unsigned char port_get_speed(unsigned char port_num)
{
  port_num = port_num_transfer(port_num);
	if(port_num>23)
	{
		if(read_reg_common(1,IP1826_SPEED03,port_num-24))
		{	return PORT_SPEED_1000M;	}
	}

	return read_reg_common(2,IP1826_SPEED,port_num);
}
void port_set_speed_all(unsigned long port)
{
  port = port_bit_transfer(port);
	write_reg(IP1826_SPEED01,(unsigned short)(port&0xffff));
	write_reg(IP1826_SPEED02,(unsigned short)(port>>16));
}
unsigned long port_get_speed_all(void)
{
	unsigned long port;
	port = read_reg(IP1826_SPEED01);
	port |= (unsigned long)read_reg(IP1826_SPEED02)<<16;
	return port_bit_transfer_R(port);
}

void port_set_speed_GIGA(unsigned char port_num,unsigned char mode)
{
  port_num = port_num_transfer(port_num);
	write_reg_common(1,IP1826_SPEED03,port_num-24,mode);	
}
unsigned char port_get_speed_GIGA(unsigned char port_num)
{
  port_num = port_num_transfer(port_num);
	return read_reg_common(1,IP1826_SPEED03,port_num-24);
}

void port_set_mdi_auto(unsigned char port_num,unsigned char enabled)
{
    unsigned short reg_val=0,reg_data=0;

    port_num = port_num_transfer(port_num);
    reg_val = port_num+8;
    reg_val |= (unsigned short)23<<5;
    reg_val |= (unsigned short)0x1<<15;
//    printf("set reg_val=%x in set\n",reg_val);
    write_reg(IP1826_PHY_CMD,reg_val);
    
    do{reg_data=read_reg(IP1826_PHY_CMD);}while((reg_data&((unsigned short)0x1<<13))==0);
//    printf("i=%d\n",i);
    reg_data = read_reg(IP1826_PHY_DATA);
    reg_data &= ~(0x1<<(port_num%8+8));
    reg_data |= (unsigned short)enabled <<(port_num%8+8);
  //  printf("set reg_val=%x\n",reg_data);
    write_reg(IP1826_PHY_DATA,reg_data);
    reg_val |= (unsigned short)0x1<<14;
    write_reg(IP1826_PHY_CMD,reg_val);
	do{reg_data=read_reg(IP1826_PHY_CMD);}while((reg_data&((unsigned short)0x1<<13))==0);
}
unsigned char port_get_mdi_auto(unsigned char port_num)
{
    unsigned short reg_val=0,reg_data=0;

    port_num = port_num_transfer(port_num);
    reg_val = port_num+8;
    reg_val |= (unsigned short)23<<5;
    reg_val |= (unsigned short)0x1<<15;
//    printf("set reg_val=%x in get\n",reg_val);
    write_reg(IP1826_PHY_CMD,reg_val);
    do{reg_data=read_reg(IP1826_PHY_CMD);}while((reg_data&((unsigned short)0x1<<13))==0);
//    printf("i=%d\n",i);
    reg_data = read_reg(IP1826_PHY_DATA);
//    printf("get reg_val=%x\n",reg_data);
    return ((reg_data>>(port_num%8+8))&0x1);
}

void port_set_mdi_mode(unsigned char port_num,unsigned char mode)
{
    unsigned short reg_val=0,reg_data=0;

    port_num = port_num_transfer(port_num);
    reg_val = port_num+8;
    reg_val |= (unsigned short)23<<5;
    reg_val |= (unsigned short)0x1<<15;
//    printf("set reg_val=%x in set\n",reg_val);
    write_reg(IP1826_PHY_CMD,reg_val);
    
    do{reg_data=read_reg(IP1826_PHY_CMD);}while((reg_data&((unsigned short)0x1<<13))==0);
//    printf("i=%d\n",i);
    reg_data = read_reg(IP1826_PHY_DATA);
    reg_data &= ~(0x1<<(port_num%8));
    reg_data |= (unsigned short)mode <<(port_num%8);
  //  printf("set reg_val=%x\n",reg_data);
    write_reg(IP1826_PHY_DATA,reg_data);
    reg_val |= (unsigned short)0x1<<14;
    write_reg(IP1826_PHY_CMD,reg_val);
	do{reg_data=read_reg(IP1826_PHY_CMD);}while((reg_data&((unsigned short)0x1<<13))==0);

}
unsigned char port_get_mdi_mode(unsigned char port_num)
{
    unsigned short reg_val=0,reg_data=0;

    port_num = port_num_transfer(port_num);
    reg_val = port_num+8;
    reg_val |= (unsigned short)23<<5;
    reg_val |= (unsigned short)0x1<<15;
//    printf("set reg_val=%x in get\n",reg_val);
    write_reg(IP1826_PHY_CMD,reg_val);
    do{reg_data=read_reg(IP1826_PHY_CMD);}while((reg_data&((unsigned short)0x1<<13))==0);
//    printf("i=%d\n",i);
    reg_data = read_reg(IP1826_PHY_DATA);
//    printf("get reg_val=%x\n",reg_data);
    return ((reg_data>>(port_num%8))&0x1);
}
void port_set_duplex(unsigned char port_num,unsigned char mode)
{
  port_num = port_num_transfer(port_num);
	write_reg_common(2,IP1826_DUPLEX,port_num,mode);
}

unsigned char port_get_duplex(unsigned char port_num)
{
  port_num = port_num_transfer(port_num);
	return read_reg_common(2,IP1826_DUPLEX,port_num);
}
void port_set_duplex_all(unsigned long port)
{
  port = port_bit_transfer(port);
	write_reg(IP1826_DUPLEX01,(unsigned short)(port&0xffff));
	write_reg(IP1826_DUPLEX02,(unsigned short)(port>>16));
}
unsigned long port_get_duplex_all(void)
{
	unsigned long port;
	port = read_reg(IP1826_DUPLEX01);
	port |= (unsigned long)read_reg(IP1826_DUPLEX02)<<16;
	return port_bit_transfer_R(port);
}
//Receive enable
void port_set_rx_enable(unsigned char port_num,unsigned char enabled)
{
  port_num = port_num_transfer(port_num);
	write_reg_common(2,IP1826_PORT_RECEIVE,port_num,enabled);
}
unsigned char port_get_rx_enable(unsigned char port_num)
{
  port_num = port_num_transfer(port_num);
	return read_reg_common(2,IP1826_PORT_RECEIVE,port_num);
}
void port_set_rx_enable_all(unsigned long ports)
{
  ports = port_bit_transfer(ports);
	write_reg(IP1826_PORT_RECEIVE_01,(unsigned short)(ports&0xffff));
	write_reg(IP1826_PORT_RECEIVE_02,(unsigned short)(ports>>16));
}
unsigned long port_get_rx_enable_all(void)
{
	unsigned long ports;
	ports = read_reg(IP1826_PORT_RECEIVE_01);
	ports |= (unsigned long)read_reg(IP1826_PORT_RECEIVE_02)<<16;
	return port_bit_transfer_R(ports);
}
//Transmit enable
void port_set_tx_enable(unsigned char port_num,unsigned char enabled)
{
  port_num = port_num_transfer(port_num);
	if(port_num<26)
	{	write_reg_common(2,IP1826_TRANSMIT_ENABLE,port_num,enabled);	}
}
unsigned char port_get_tx_enable(unsigned char port_num)
{
  port_num = port_num_transfer(port_num);
	if(port_num<26)
	{	return read_reg_common(2,IP1826_TRANSMIT_ENABLE,port_num);	}
	else
	{	return	0;	}
}
void port_set_tx_enable_all(unsigned long ports)
{
	unsigned short reg_val = read_reg(IP1826_TRANSMIT_ENABLE_02)&~(0x3ff);
	ports = port_bit_transfer(ports);
	write_reg(IP1826_TRANSMIT_ENABLE_01,(unsigned short)(ports&0xffff));
	write_reg(IP1826_TRANSMIT_ENABLE_02,(unsigned short)(ports>>16)|reg_val);
}
unsigned long port_get_tx_enable_all(void)
{
	unsigned long ports;
	ports = read_reg(IP1826_TRANSMIT_ENABLE_01);
	ports |= (unsigned long)(read_reg(IP1826_TRANSMIT_ENABLE_02)&0x3ff)<<16;
	return port_bit_transfer_R(ports);
}
//learning enable
void port_set_learning(unsigned char port_num,unsigned char enabled)
{
  port_num = port_num_transfer(port_num);
	write_reg_common(2,IP1826_MAC_ADDR_LEARNING,port_num,enabled);
}
unsigned char port_get_learning(unsigned char port_num)
{
  port_num = port_num_transfer(port_num);
	return read_reg_common(2,IP1826_MAC_ADDR_LEARNING,port_num);
}
void port_set_learning_all(unsigned long ports)
{
  ports = port_bit_transfer(ports);
	write_reg(IP1826_MAC_ADDR_LEARNING_01,(unsigned short)(ports&0xffff));
	write_reg(IP1826_MAC_ADDR_LEARNING_02,(unsigned short)(ports>>16));
}
unsigned long port_get_learning_all(void)
{
	unsigned long ports;
	ports = read_reg(IP1826_MAC_ADDR_LEARNING_01);
	ports |= (unsigned long)read_reg(IP1826_MAC_ADDR_LEARNING_02)<<16;
	return port_bit_transfer_R(ports);
}
//forwarding state
void port_set_forwarding(unsigned char port_num, unsigned char enabled)
{
  port_num = port_num_transfer(port_num);
	write_reg_common(2,IP1826_RECEIVE_FORWARDING,port_num,enabled);
}
unsigned char port_get_forwarding(unsigned char port_num)
{
  port_num = port_num_transfer(port_num);
	return read_reg_common(2,IP1826_RECEIVE_FORWARDING, port_num);
}
void port_set_forwarding_all(unsigned long ports)
{
  ports = port_bit_transfer(ports);
	write_reg(IP1826_RECEIVE_FORWARDING_01,(unsigned short)(ports&0xffff));
	write_reg(IP1826_RECEIVE_FORWARDING_02,(unsigned short)(ports>>16));
}
unsigned long port_get_forwarding_all(void)
{
	unsigned long ports;
	ports = read_reg(IP1826_RECEIVE_FORWARDING_01);
	ports |= (unsigned long)read_reg(IP1826_RECEIVE_FORWARDING_02)<<16;
	return port_bit_transfer_R(ports);
}


void port_set_pause_fiber(unsigned char port_num,unsigned char enabled)
{	
	unsigned short reg_val=0,reg_data=0;

  port_num = port_num_transfer(port_num);	
	reg_val = (port_num%2)+1;	//PHY number
	reg_val |= (unsigned short)0x4<<5;		//MII register 4
	reg_val |= (unsigned short)0x1<<12;	//PCS command trigger
//	reg_val |= (unsigned short)0x1<<15;	//PHY command trigger
	
	write_reg(IP1826_PHY_CMD,reg_val);
	do{
		reg_data=read_reg(IP1826_PHY_CMD);
	}while((reg_data&((unsigned short)0x1<<13))==0);
	
	
	reg_data = read_reg(IP1826_PHY_DATA);
	reg_data &= ~((unsigned short)0x3<<7);
	reg_data |= (enabled==1)?((unsigned short)0x3<<7):(unsigned short)0x0;
	
	write_reg(IP1826_PHY_DATA,reg_data);
	reg_val |= (unsigned short)0x1<<14;

	write_reg(IP1826_PHY_CMD,reg_val);
	do{
		reg_data=read_reg(IP1826_PHY_CMD);
	}while((reg_data&((unsigned short)0x1<<13))==0);
	
	port_set_restart_AN_fiber(port_num);
}

unsigned char port_get_pause_fiber(unsigned char port_num)
{
	unsigned short reg_val=0,reg_data=0;

  port_num = port_num_transfer(port_num);	
	reg_val = (port_num%2)+1;	//PHY number
	reg_val |= (unsigned short)0x4<<5;		//MII register 4
	reg_val |= (unsigned short)0x1<<12;	//PCS command trigger
//	reg_val |= (unsigned short)0x1<<15;	//PHY command trigger
	
	write_reg(IP1826_PHY_CMD,reg_val);
	do{
		reg_data=read_reg(IP1826_PHY_CMD);
	}while((reg_data&((unsigned short)0x1<<13))==0);
	
	
	reg_data = read_reg(IP1826_PHY_DATA);
	
	return ((reg_data>>7)&0x3)?0x3:0x0;
}

void port_set_pause(unsigned char port_num,unsigned char type,unsigned char enabled)
{	
  port_num = port_num_transfer(port_num);
	if(type == PAUSE_RX)
		write_reg_common(2,IP1826_PAUSE,port_num,enabled);
	else
		write_reg_common(2,IP1826_ASYMMERTIC_PAUSE,port_num,enabled);
}

unsigned char port_get_pause(unsigned char port_num,unsigned char type)
{
  port_num = port_num_transfer(port_num);
	if(type == PAUSE_RX)
		return read_reg_common(2,IP1826_PAUSE,port_num);
	else
		return read_reg_common(2,IP1826_ASYMMERTIC_PAUSE,port_num);
}

void port_set_pause_all(unsigned char type,unsigned long port)
{
  port = port_bit_transfer(port);
	if(type == PAUSE_RX){
		write_reg(IP1826_PAUSE01,(unsigned short)(port&0xffff));
		write_reg(IP1826_PAUSE02,(unsigned short)(port>>16));
	}		
	else{
		write_reg(IP1826_ASYMMERTIC_PAUSE_01,(unsigned short)(port&0xffff));
		write_reg(IP1826_ASYMMERTIC_PAUSE_02,(unsigned short)(port>>16));				
	}
}

unsigned long port_get_pause_all(unsigned char type)
{
	unsigned long port;
	if(type == PAUSE_RX)	{
		port = read_reg(IP1826_PAUSE01);
		port |= (unsigned long)read_reg(IP1826_PAUSE02)<<16;
	}
	else{
		port = read_reg(IP1826_ASYMMERTIC_PAUSE_01);
		port |= (unsigned long)read_reg(IP1826_ASYMMERTIC_PAUSE_02)<<16;	
	}
	return port_bit_transfer_R(port);
}

void port_set_backpressure(unsigned char port_num,unsigned char enabled)
{
  port_num = port_num_transfer(port_num);
	write_reg_common(2,IP1826_BACKPRESSURE,port_num,enabled);
}

unsigned char port_get_backpressure(unsigned char port_num)
{
  port_num = port_num_transfer(port_num);
	return read_reg_common(2,IP1826_BACKPRESSURE,port_num);
}
void port_set_backpressure_all(unsigned long port)
{
  port = port_bit_transfer(port);
	write_reg(IP1826_BACKPRESSURE01,(unsigned short)(port&0xffff));
	write_reg(IP1826_BACKPRESSURE02,(unsigned short)(port>>16));
}
unsigned long port_get_backpressure_all(void)
{
	unsigned long port;
	port = read_reg(IP1826_BACKPRESSURE01);
	port |= (unsigned long)read_reg(IP1826_BACKPRESSURE02)<<16;
	return port_bit_transfer_R(port);
}

void port_set_backpressure_func(unsigned char func)
{
	write_reg_common(1,IP1826_GENERAL_MAC_OPERATUON_BEHAVIOR,2,func);
}
unsigned char port_get_backpressure_func(void)
{
	return read_reg_common(1,IP1826_GENERAL_MAC_OPERATUON_BEHAVIOR,2);
}

void port_set_broadcast_storm_protection(unsigned char port_num,unsigned char enabled)
{
  port_num = port_num_transfer(port_num);
	write_reg_common(2,IP1826_BROADCAST_STORM_CONTROL,port_num,enabled);
}
unsigned char port_get_broadcast_storm_protection(unsigned char port_num)
{
  port_num = port_num_transfer(port_num);
	return read_reg_common(2,IP1826_BROADCAST_STORM_CONTROL,port_num);
}

void port_set_broadcast_storm_threshold(unsigned char value)
{
	unsigned short reg_value;
	
	reg_value = read_reg(IP1826_AGING_TIMER_n_BCAST_THRESHOLD);
	reg_value &= ~((unsigned short)0x3f << 10);
	reg_value |= (unsigned short)(value&0x3f) << 10;
	
	write_reg(IP1826_AGING_TIMER_n_BCAST_THRESHOLD,reg_value);
}

unsigned char port_get_broadcast_storm_threshold(void)
{
	unsigned short reg_val;
	
	reg_val = read_reg(IP1826_AGING_TIMER_n_BCAST_THRESHOLD);
	reg_val &= ((unsigned short)0x3f<<10);
	reg_val >>= 10;

	return (unsigned char)reg_val;
}

void port_set_port_mirror(unsigned char type,unsigned long port_num)
{
  port_num = port_bit_transfer(port_num);  
	if(type==MIRROR_SOURCE_PORTS){
		write_reg(IP1826_MIRROR_SOURCE_01,(unsigned short)(port_num&0xffff));
		write_reg(IP1826_MIRROR_SOURCE_02,(unsigned short)(port_num>>16));
	}
	else{
		write_reg(IP1826_MIRROR_DEST_01,(unsigned short)(port_num&0xffff));
		write_reg(IP1826_MIRROR_DEST_02,(unsigned short)(port_num>>16));
	}
}

unsigned long port_get_port_mirror(unsigned char type)
{
	unsigned long reg_val;

	if(type==MIRROR_SOURCE_PORTS)
	{
		reg_val = read_reg(IP1826_MIRROR_SOURCE_01)&0xffff;
		reg_val |= (unsigned long)(read_reg(IP1826_MIRROR_SOURCE_02)&0x3ff)<<16;
	}
	else
	{
		reg_val = read_reg(IP1826_MIRROR_DEST_01)&0xffff;
		reg_val |= (unsigned long)(read_reg(IP1826_MIRROR_DEST_02)&0x3ff)<<16;
	}
	return port_bit_transfer_R(reg_val);
}

void port_set_port_mirror_mode(unsigned char mode)
{
	unsigned short reg_val;
	
	reg_val = read_reg(IP1826_ARL_OPERATION_SETTING);
	reg_val &= ~((unsigned short)0x3<<9);
	reg_val |= (unsigned short)(mode&0x3)<<9;
	write_reg(IP1826_ARL_OPERATION_SETTING,reg_val);
}

unsigned char port_get_port_mirror_mode(void)
{
	unsigned short reg_val;

	reg_val = read_reg(IP1826_ARL_OPERATION_SETTING);
	reg_val &= ((unsigned short)0x3<<9);
	reg_val >>= 9;
	
	return (unsigned char)reg_val;
}

void port_set_non_associate_enable(unsigned char enabled)
{
	write_reg_common(1,IP1826_PORT_EXCLUDING02,11,enabled);
}

unsigned char port_get_non_associate_enable(void)
{
	return (unsigned char)read_reg_common(1,IP1826_PORT_EXCLUDING02,11);
}

void port_set_non_associate(unsigned long port_num)
{
	unsigned short reg_val;
	port_num = port_bit_transfer(port_num);
	write_reg(IP1826_PORT_EXCLUDING01,(unsigned short)(port_num&0xffff));
	reg_val = read_reg(IP1826_PORT_EXCLUDING02)&(~0x3ff);
	write_reg(IP1826_PORT_EXCLUDING02,(unsigned short)(port_num>>16)|reg_val);
}

unsigned long port_get_non_associate(void)
{
	unsigned long reg_val;

	reg_val = read_reg(IP1826_PORT_EXCLUDING01)&0xffff;
	reg_val |= (unsigned long)(read_reg(IP1826_PORT_EXCLUDING02)&0x3ff)<<16;
	
	return port_bit_transfer_R(reg_val);
}

void port_set_bandwidth(unsigned char port_num,unsigned char dir,unsigned char bandwidth)
{
	unsigned short reg_val;

  port_num = port_num_transfer(port_num);
	reg_val = read_reg(IP1826_IOGRESS_RATE(port_num));
	if(dir == BANDWIDTH_TX){
		reg_val &= ~((unsigned short)0xff);
		reg_val |= (unsigned short)bandwidth;
	}
	else{
		reg_val &= ~(0x00ff<<8);
		reg_val |= (unsigned short)bandwidth << 8;
	}
	write_reg(IP1826_IOGRESS_RATE(port_num),reg_val);
}

unsigned char port_get_bandwidth(unsigned char port_num,unsigned char dir)
{
	unsigned short reg_val;

  port_num = port_num_transfer(port_num);
	reg_val = read_reg(IP1826_IOGRESS_RATE(port_num));

	if(dir == BANDWIDTH_TX)
		reg_val &= 0xff;
	else
		reg_val >>= 8;

	return (unsigned char)reg_val;
}

void port_set_bandwidth_func(unsigned char func)
{
	write_reg_common(1,IP1826_GENERAL_MAC_OPERATUON_BEHAVIOR,5,func);
}

unsigned char port_get_bandwidth_func(void)
{
	return read_reg_common(1,IP1826_GENERAL_MAC_OPERATUON_BEHAVIOR,5);
}

void port_set_counter_enable(unsigned char enabled)
{
	write_reg_common(1,IP1826_GENERAL_MAC_OPERATUON_BEHAVIOR,10,enabled);
}

unsigned char port_get_counter_enable(void)
{
	return read_reg_common(1,IP1826_GENERAL_MAC_OPERATUON_BEHAVIOR,10);
}

void port_set_counter_mode(unsigned char mode)
{
	write_reg_common(1,IP1826_GENERAL_MAC_OPERATUON_BEHAVIOR,9,mode);
}

unsigned char port_get_counter_mode(void)
{
	return read_reg_common(1,IP1826_GENERAL_MAC_OPERATUON_BEHAVIOR,9);
}

void port_set_counter_select(unsigned char port_num,unsigned char select)
{
  port_num = port_num_transfer(port_num);
	write_reg_common(2,IP1826_COUNTER_SELECTION,port_num,select);
}

unsigned char port_get_counter_select(unsigned char port_num)
{
  port_num = port_num_transfer(port_num);
	return read_reg_common(2,IP1826_COUNTER_SELECTION,port_num);
}

void port_set_wanfilter(unsigned char port_num,unsigned char enabled)
{
  port_num = port_num_transfer(port_num);
	write_reg_common(2,IP1826_TCP_FILTER,port_num,enabled);
}

unsigned char port_get_wanfilter(unsigned char port_num)
{
  port_num = port_num_transfer(port_num);
	return read_reg_common(2,IP1826_TCP_FILTER,port_num);
}
void port_set_wanfilter_all(unsigned long ports)
{
  ports = port_bit_transfer(ports);
	write_reg(IP1826_TCP_FILTER_0,(unsigned short)(ports&0xffff));
	write_reg(IP1826_TCP_FILTER_1,(unsigned short)(ports>>16)&0x3ff);
}
unsigned long port_get_wanfilter_all(void)
{
	unsigned long ports;
	ports = read_reg(IP1826_TCP_FILTER_0);
	ports |= (unsigned long)read_reg(IP1826_TCP_FILTER_1)<<16;	
	return port_bit_transfer_R(ports);
}

void port_set_wanfilter_mode(unsigned char mode)
{
	write_reg_common(1,IP1826_TCP_FILTER_PRIORITY_CMD,8,mode);
}

unsigned char port_get_wanfilter_mode(void)
{
	return read_reg_common(1,IP1826_TCP_FILTER_PRIORITY_CMD,8);
}

void port_set_wanfilter_enable(unsigned char enabled)
{
	write_reg_common(1,IP1826_TCP_FILTER_PRIORITY_CMD,9,enabled);
}

unsigned char port_get_wanfilter_enable(void)
{
	return read_reg_common(1,IP1826_TCP_FILTER_PRIORITY_CMD,9);
}

void port_set_wanfilter_protocol(unsigned char idx,unsigned char enabled)
{
	write_reg_common(2,IP1826_TCP_FILTER_PRIORITY,idx,enabled);
}

unsigned char port_get_wanfilter_protocol(unsigned char idx)
{
	return read_reg_common(2,IP1826_TCP_FILTER_PRIORITY,idx);
}
void port_set_wanfilter_protocol_all(unsigned long protocols)
{
	unsigned short reg_val = read_reg(IP1826_TCP_FILTER_PRIORITY_1)&(0xff00);
	write_reg(IP1826_TCP_FILTER_PRIORITY_0,(unsigned short)(protocols&0xffff));
	write_reg(IP1826_TCP_FILTER_PRIORITY_1,(unsigned short)((protocols>>16)&0xff)|reg_val);
}
unsigned long port_get_wanfilter_protocol_all(void){
	unsigned long protocols;
	protocols = read_reg(IP1826_TCP_FILTER_PRIORITY_0);
	protocols |= (unsigned long)(read_reg(IP1826_TCP_FILTER_PRIORITY_1)&0xff)<<16;	
	return protocols;
}

unsigned char	port_get_status(unsigned char port_num)
{
	unsigned short reg_val;
  port_num = port_num_transfer(port_num);
	reg_val = read_reg(IP1826_PORT_STATUS+(unsigned short)(port_num/3));
	reg_val	>>= (port_num%3)*5;
	reg_val &= 0x1f;

	if(port_num<24)
	{
		reg_val = read_reg(IP1826_PORT_STATUS+(unsigned short)(port_num/3));
		reg_val	>>= (port_num%3)*5;
		reg_val &= 0x1f;
	}
	else if(port_num<26)
	{
		reg_val = read_reg(IP1826_PORT_STATUS_FIBER);
		reg_val	>>= (port_num%2)*6;
		reg_val &= 0x3f;
	}
	else
	{	reg_val = 0;	}

	return (unsigned char)reg_val;
}

unsigned char	port_get_status_GIGA(unsigned char port_num)
{
	unsigned short reg_val;

  port_num = port_num_transfer(port_num);
	reg_val = read_reg(IP1826_PORT_STATUS_FIBER);
	reg_val	>>= (port_num%2)*6;
	reg_val &= 0x3f;

	return (unsigned char)reg_val;
}

unsigned char	port_get_link(unsigned char port_num)
{
	unsigned short reg_val;

  port_num = port_num_transfer(port_num);
	if(port_num<24)
	{
		reg_val = read_reg(IP1826_PORT_STATUS+(unsigned short)(port_num/3));
		reg_val	>>= (port_num%3)*5;
		reg_val &= 0x1;
	}
	else if(port_num<26)
	{
		reg_val = read_reg(IP1826_PORT_STATUS_FIBER);
		reg_val	>>= (port_num%2)*6;
		reg_val &= 0x1;
	}
	else
	{	reg_val = 0;	}

	return (unsigned char)reg_val;
}

unsigned char	port_get_link_fiber(unsigned char port_num)
{
	unsigned short reg_val=0,reg_data=0;

  port_num = port_num_transfer(port_num);	
	reg_val = (port_num%2)+1;	//PHY number
	reg_val |= (unsigned short)0x1<<5;		//MII register 1
	reg_val |= (unsigned short)0x1<<12;	//PCS command trigger
//	reg_val |= (unsigned short)0x1<<15;	//PHY command trigger
	
	write_reg(IP1826_PHY_CMD,reg_val);
	do{
		reg_data=read_reg(IP1826_PHY_CMD);
	}while((reg_data&((unsigned short)0x1<<13))==0);
	
	
	reg_data = read_reg(IP1826_PHY_DATA);
	
	return ((reg_data>>2)&0x1);	//PCS register bit 2
}

/*
unsigned char	port_get_status_item(unsigned char port_num, unsigned char item)
{
	unsigned short reg_val;

	reg_val = read_reg(IP1826_PORT_STATUS+(unsigned short)(port_num/3));
	reg_val	>>= ((port_num%3)*5 + item);
	reg_val &= 0x1;

	return (unsigned char)reg_val;	
}
*/
unsigned long port_get_counter(unsigned char port_num,unsigned char which)
{
	unsigned long reg_val;

  port_num = port_num_transfer(port_num);
	if(port_num<24)
	{
		write_reg(IP1826_COUNTER_STATUS_COMMAND,(unsigned short)((port_num*2+which)|(0x0001<<8)));
		reg_val = (unsigned long)read_reg(IP1826_COUNTER_STATUS_DATA_LO);
		reg_val |= (unsigned long)read_reg(IP1826_COUNTER_STATUS_DATA_HI)<<16;
	}
	else if(port_num<26)
	{
		write_reg(IP1826_COUNTER_STATUS_COMMAND,(unsigned short)(((port_num+1)*2+which)|(0x0001<<8)));
		reg_val = (unsigned long)read_reg(IP1826_COUNTER_STATUS_DATA_LO);
		reg_val |= (unsigned long)read_reg(IP1826_COUNTER_STATUS_DATA_HI)<<16;
	}
	else if(port_num==CPU_PORT)
	{
		write_reg(IP1826_COUNTER_STATUS_COMMAND,(unsigned short)((24*2+which)|(0x0001<<8)));
		reg_val = (unsigned long)read_reg(IP1826_COUNTER_STATUS_DATA_LO);
		reg_val |= (unsigned long)read_reg(IP1826_COUNTER_STATUS_DATA_HI)<<16;
	}
	else
	{	reg_val=0;	}

	return reg_val;
}

void port_clear_counter(void)
{
    write_reg(IP1826_COUNTER_STATUS_COMMAND,0x180);
}

void port_set_force_link(unsigned char port_num, unsigned char enabled)
{
	unsigned short reg_val;
	port_num = port_num_transfer(port_num);
	reg_val = read_reg(IP1826_TRANSMIT_ENABLE_02);
	reg_val &= ~(0x01<<(port_num-13));	//portnum-24+11
	reg_val |= (unsigned short)(enabled&0x1)<<(port_num-13);	//(port_num-24+11)
    write_reg(IP1826_TRANSMIT_ENABLE_02,reg_val);
}

unsigned char port_get_force_link(unsigned char port_num)
{
	unsigned short reg_val;
	port_num = port_num_transfer(port_num);
	reg_val = read_reg(IP1826_TRANSMIT_ENABLE_02);
	reg_val >>= (port_num-13);
	reg_val &= 0x1;
	return (unsigned char)reg_val;
}
//========================================================================================
// STP
//========================================================================================
void set_bpdu_bcast(unsigned char enabled)
{
	write_reg_common(1,IP1826_GENERAL_MAC_OPERATUON_BEHAVIOR,1,enabled);
}

unsigned char get_bpdu_bcast(void)
{
	return read_reg_common(1,IP1826_GENERAL_MAC_OPERATUON_BEHAVIOR,1);
}

void set_cpu_interface_mode(unsigned char mode)
{
	write_reg_common(1,IP1826_CPU_MODE,2,mode);
}

unsigned char get_cpu_interface_mode(void)
{
	return read_reg_common(1,IP1826_CPU_MODE,2);
}

void set_special_tag_enable(unsigned char enabled)
{
	write_reg_common(1,IP1826_CPU_MODE,1,enabled);
}

unsigned char get_special_tag_enable(void)
{
	return read_reg_common(1,IP1826_CPU_MODE,1);
}

void set_cpu_mode_enable(unsigned char enabled)
{
	write_reg_common(1,IP1826_CPU_MODE,0,enabled);	
}

unsigned char get_cpu_mode_enable(void)
{
	return (unsigned char)read_reg_common(1,IP1826_CPU_MODE,0);
}

void stp_set_port_state(unsigned char port_num,unsigned char state)
{
  port_num = port_num_transfer(port_num);
	write_reg_common(2,IP1826_PORT_RECEIVE,			port_num,	(state==PORT_STATE_DISCARD)?0x0:0x1);
	write_reg_common(2,IP1826_TRANSMIT_ENABLE,		port_num,	(state<PORT_STATE_LISTENING)?0x0:0x1);
	write_reg_common(2,IP1826_MAC_ADDR_LEARNING,	port_num,	(state<PORT_STATE_LEARNING)?0x0:0x1);
	write_reg_common(2,IP1826_RECEIVE_FORWARDING,	port_num,	(state==PORT_STATE_FORWARD)?0x1:0x0);
}

unsigned char stp_get_port_state(unsigned char port_num)
{
	unsigned char	rx, tx, learn, forward;

  port_num = port_num_transfer(port_num);	
	rx = read_reg_common(2,IP1826_PORT_RECEIVE, port_num);
	tx = read_reg_common(2,IP1826_TRANSMIT_ENABLE, port_num);
	learn = read_reg_common(2,IP1826_MAC_ADDR_LEARNING, port_num);
	forward = read_reg_common(2,IP1826_RECEIVE_FORWARDING, port_num);

	if(rx==0)
	{	return PORT_STATE_DISCARD;	}
	else if(tx==0)
	{	return PORT_STATE_BLOCK;	}
	else if(learn==0)
	{	return PORT_STATE_LISTENING;	}
	else if(forward==0)
	{	return PORT_STATE_LEARNING;	}
	else
	{	return PORT_STATE_FORWARD;	}
}

//========================================================================================
// TRUNK
//========================================================================================
void trunk_set_group_member(unsigned char idx,unsigned short member)
{
	write_reg(IP1826_TRUNK_GROUP+idx,member);		//write Trunk group1
}

unsigned short trunk_get_group_member(unsigned char idx)
{
	return read_reg(IP1826_TRUNK_GROUP+idx);		//write Trunk group1
}

void trunk_set_func(unsigned char func)
{
	unsigned short reg_val;

	reg_val = read_reg(IP1826_ARL_OPERATION_SETTING);
	reg_val &= ~((unsigned short)0x3<<2);
	reg_val |= (unsigned short)(func&0x3)<<2;

	write_reg(IP1826_ARL_OPERATION_SETTING,reg_val);
}

unsigned char trunk_get_func(void)
{
	unsigned short reg_val;

	reg_val = read_reg(IP1826_ARL_OPERATION_SETTING);
	reg_val >>= 2;
	reg_val &= (unsigned short)0x3;
	
	return (unsigned char)reg_val;
}

//========================================================================================
//	IGMP
//========================================================================================

void igmp_set_func(unsigned short func)
{
	write_reg(IP1826_IGMP_SNOOPING_FUNCTION,func);
}

unsigned short igmp_get_func(void)
{
	return read_reg(IP1826_IGMP_SNOOPING_FUNCTION);
}
void igmp_set_router_port(unsigned long router_ports)
{
  router_ports = port_bit_transfer(router_ports);
	write_reg(IP1826_IGMP_ROUTER_PORT_SELECTION_0,(unsigned short)(router_ports&0xffff));
	write_reg(IP1826_IGMP_ROUTER_PORT_SELECTION_1,(unsigned short)(router_ports>>16));
}

unsigned long igmp_get_router_port(void)
{
	unsigned long reg_val;

	reg_val = read_reg(IP1826_IGMP_ROUTER_PORT_SELECTION_0)&0xffff;
	reg_val |= (unsigned long)(read_reg(IP1826_IGMP_ROUTER_PORT_SELECTION_1)&0x3ff)<<16;

	return port_bit_transfer_R(reg_val);
}

void igmp_set_enabled(unsigned char enabled)
{
	write_reg_common(1,IP1826_IGMP_SNOOPING_FUNCTION,0,enabled);
}

unsigned char igmp_get_enabled(void)
{
	return (unsigned char)read_reg_common(1,IP1826_IGMP_SNOOPING_FUNCTION,0);
}

void set_block_bcast_to_cpu(unsigned char enabled)
{
	write_reg_common(1,IP1826_ARL_OPERATION_SETTING,4,enabled);
}

unsigned char get_block_bcast_to_cpu(void)
{
	return (unsigned char)read_reg_common(1,IP1826_ARL_OPERATION_SETTING,4);
}

void set_pass_ipv4_to_cpu(unsigned char enabled)
{
	write_reg_common(1,IP1826_ARL_OPERATION_SETTING,5,enabled);
}

unsigned char get_pass_ipv4_to_cpu(void)
{
	return (unsigned char)read_reg_common(1,IP1826_ARL_OPERATION_SETTING,5);
}

//========================================================================================
//	MISC
//========================================================================================
/*	No plan to implement yet */
/*
void misc_set_aging(unsigned char type,unsigned long time);
void misc_set_arp_icmp_storm_ctrl(unsigned char type,unsigned char enabled);
*/

//========================================================================================
// LUT
//========================================================================================
void lut_set_hash_algorithm(unsigned char sel)
{
	write_reg_common(1,IP1826_ARL_OPERATION_SETTING,0,sel);
}
unsigned char lut_get_hash_algorithm(void)
{
	return read_reg_common(1,IP1826_ARL_OPERATION_SETTING,0);
}
void lut_flush_table(void)
{
	write_reg_common(1,IP1826_LUT,0,0);
	write_reg_common(1,IP1826_LUT,0,1);
	while(read_reg_common(1,IP1826_LUT,5));
	
}

void lut_flush_port(unsigned char port)
{
	unsigned short idx;
	unsigned short ctrl,data3;

  port = port_num_transfer(port);   
	for(idx=0;idx<MAX_MAC_LUT_ENTRY;idx++)
	{
    ctrl=idx|0x4000;
		write_reg(IP1826_ACCESS_LUT_COMMAND,ctrl);
		while(!(read_reg(IP1826_ACCESS_LUT_COMMAND)&0x8000));//wait for reading LUT.
#ifdef LUT_TWICE_BUG
		write_reg(IP1826_ACCESS_LUT_COMMAND,ctrl);
		while(!(read_reg(IP1826_ACCESS_LUT_COMMAND)&0x8000));//wait for reading LUT.
#endif// LUT_TWICE_BUG
		
		data3=read_reg(IP1826_ACCESS_LUT_DATA_3);
		if((data3&0x3c00)==0 || (data3&0x200)||((unsigned char)((data3>>4)&0x1f)!=port))
		continue;
		
		write_reg(IP1826_ACCESS_LUT_DATA_3,0x0);
		write_reg(IP1826_ACCESS_LUT_DATA_2,0x0);
		write_reg(IP1826_ACCESS_LUT_DATA_1,0x0);
    ctrl=idx|0x7000; 
		write_reg(IP1826_ACCESS_LUT_COMMAND,ctrl);        
		while(!(read_reg(IP1826_ACCESS_LUT_COMMAND)&0x8000));		
	}
}

void lut_flush_igmp(void)
{
	unsigned short idx;
	unsigned short ctrl,data3;
	
	for(idx=0;idx<MAX_MAC_LUT_ENTRY;idx++)
	{
    ctrl=idx|0x4000;
		write_reg(IP1826_ACCESS_LUT_COMMAND,ctrl);
		while(!(read_reg(IP1826_ACCESS_LUT_COMMAND)&0x8000));//wait for reading LUT.
#ifdef LUT_TWICE_BUG
		write_reg(IP1826_ACCESS_LUT_COMMAND,ctrl);
		while(!(read_reg(IP1826_ACCESS_LUT_COMMAND)&0x8000));//wait for reading LUT.
#endif// LUT_TWICE_BUG
		
		data3=read_reg(IP1826_ACCESS_LUT_DATA_3);
		if((data3&0x3c00)==0 || !(data3&0x200) ||(data3&0x100))
		continue;
		
		write_reg(IP1826_ACCESS_LUT_DATA_3,0x0);
		write_reg(IP1826_ACCESS_LUT_DATA_2,0x0);
		write_reg(IP1826_ACCESS_LUT_DATA_1,0x0); 
    ctrl=idx|0x7000; 
		write_reg(IP1826_ACCESS_LUT_COMMAND,ctrl);        
		while(!(read_reg(IP1826_ACCESS_LUT_COMMAND)&0x8000));
		
	}
}


void lut_scan_mac(unsigned char port,unsigned char *mac_idx_map,unsigned short idx_start,unsigned short idx_end)
{
	unsigned short i=0;
	//lut_entry lut; 
	unsigned short ctrl,data3;

  if(lut_get_hash_algorithm()==LUT_HASH_CRC)
  {return;}

  port = port_num_transfer(port);
  for(i=idx_start;i<idx_end;i++)
	{
		ctrl = 0x4000 | i;
		write_reg(IP1826_ACCESS_LUT_COMMAND,ctrl);
		while(!(read_reg(IP1826_ACCESS_LUT_COMMAND)&0x8000));//wait for reading LUT.	
#ifdef LUT_TWICE_BUG
		write_reg(IP1826_ACCESS_LUT_COMMAND,ctrl);
		while(!(read_reg(IP1826_ACCESS_LUT_COMMAND)&0x8000));//wait for reading LUT.
#endif// LUT_TWICE_BUG
		data3=read_reg(IP1826_ACCESS_LUT_DATA_3);

		if((data3&0x3c00)==0||(data3&0x200)||((unsigned char)((data3>>4)&0x1f)!=port))
		continue;
		*(mac_idx_map+(i/8))|=(unsigned char)0x1<<(i%8);
		
    }
}

void lut_set_mac(struct _lut_mac_entry lut_mac_entry)
{
	//lut_entry lut;
	unsigned short ctrl,data1,data2,data3;
	ctrl=data1=data2=data3=0;
//IP1826_ACCESS_LUT_COMMAND
	/*lut.mac.command = 0x7;
	lut.mac.mac5	= (unsigned char)lut_mac_entry.mac_addr[5];
	lut.mac.mac4L	= (unsigned char)lut_mac_entry.mac_addr[4]&0x0f;*/
	if(lut_get_hash_algorithm()==LUT_HASH_CRC)
	{  ctrl=crc_16((unsigned char *)&lut_mac_entry.mac_addr); }
	else
	{  ctrl = (lut_mac_entry.mac_addr[5] | ((lut_mac_entry.mac_addr[4]&0x0f)<<8));  } 
	ctrl|=0x7000;
//IP1826_ACCESS_LUT_DATA_1
/*	lut.mac.mac4H	= ((unsigned char)lut_mac_entry.mac_addr[4]>>4)&0xf;
	lut.mac.mac3	= (unsigned char)lut_mac_entry.mac_addr[3];
	lut.mac.mac2L	= (unsigned char)lut_mac_entry.mac_addr[2]&0xf; */
	data1 = (unsigned short)((lut_mac_entry.mac_addr[4]>>4)&0xf);
  data1 |= (((unsigned short)lut_mac_entry.mac_addr[3])<<4)&0xff0;
  data1 |= (((unsigned short)lut_mac_entry.mac_addr[2])&0xf)<<12;   
//IP1826_ACCESS_LUT_DATA_2
/*	lut.mac.mac2H	= ((unsigned char)lut_mac_entry.mac_addr[2]>>4)&0xf;
	lut.mac.mac1	= (unsigned char)lut_mac_entry.mac_addr[1];
	lut.mac.mac0L	= ((unsigned char)lut_mac_entry.mac_addr[0]>>1)&0xf;*/
	data2 = (unsigned short)((lut_mac_entry.mac_addr[2]>>4)&0xf);
  data2 |= (((unsigned short)lut_mac_entry.mac_addr[1])<<4)&0xff0;
  data2 |= (((unsigned short)lut_mac_entry.mac_addr[0])&0xf)<<12; 	
//IP1826_ACCESS_LUT_DATA_3
/*  lut.mac.mac0H	= ((unsigned char)lut_mac_entry.mac_addr[0]>>5)&0x7;
  lut.mac.sa		= lut_mac_entry.sa&0x1;
  lut.mac.port_num= lut_mac_entry.port_num&0x1f;
  lut.mac.type	= 0;
  lut.mac.aging	= lut_mac_entry.aging&0xf; */
  data3 = (unsigned short)((lut_mac_entry.mac_addr[0]>>4)&0x7);
  data3 |= (unsigned short)((lut_mac_entry.sa&0x1)<<3);
  data3 |= (unsigned short)(port_num_transfer((lut_mac_entry.port_num&0x1f))<<4);
  data3 |= (unsigned short)((lut_mac_entry.aging&0xf)<<10);
  
//write_reg
	write_reg(IP1826_ACCESS_LUT_DATA_1, data1);
	write_reg(IP1826_ACCESS_LUT_DATA_2, data2);
	write_reg(IP1826_ACCESS_LUT_DATA_3, data3);
	write_reg(IP1826_ACCESS_LUT_COMMAND, ctrl);
    while(!(read_reg(IP1826_ACCESS_LUT_COMMAND)&0x8000));//wait for reading LUT.

	
}

struct _lut_mac_entry lut_get_mac(unsigned short index)
{
	struct _lut_mac_entry lut_mac_entry;
	unsigned short ctrl,data1,data2,data3;
	
	if(lut_get_hash_algorithm()==LUT_HASH_CRC)
	{
		lut_mac_entry.aging=0;
		return lut_mac_entry;		
	}
	
  ctrl=data1=data2=data3=0;	
  memset(&lut_mac_entry,0x0,sizeof(struct _lut_mac_entry));
#ifdef IP1826_DBG_MSG	
  printk("lut_get_mac index[0x%x]\n",(unsigned int)index);
#endif  
	ctrl=(index&0xfff)|0x4000;
	write_reg(IP1826_ACCESS_LUT_COMMAND,ctrl);
	while(!(read_reg(IP1826_ACCESS_LUT_COMMAND)&0x8000));//wait for reading LUT.

	data3=read_reg(IP1826_ACCESS_LUT_DATA_3);	
	if((data3&0x3c00)==0 || (data3&0x200))
	{
		lut_mac_entry.aging=0;
		return lut_mac_entry;		
	}

	data2=read_reg(IP1826_ACCESS_LUT_DATA_2);
	data1=read_reg(IP1826_ACCESS_LUT_DATA_1);
#ifdef IP1826_DBG_MSG
  printk("data1[0x%x]data2[0x%x]data3[0x%x]\n",(unsigned int)data1,(unsigned int)data2,(unsigned int)data3);
#endif  
	lut_mac_entry.aging=(unsigned char)((data3>>10)&0xf);
	lut_mac_entry.port_num=port_num_transfer_R((unsigned char)((data3>>4)&0x1f));
	lut_mac_entry.sa=(unsigned char)((data3>>3)&0x1);

	lut_mac_entry.mac_addr[0]=	(unsigned char)((data3&0x7)<<5)| ((data2&0xf000)>>11);
	lut_mac_entry.mac_addr[1] = (unsigned char)((data2&0xff0)>>4);
	lut_mac_entry.mac_addr[2] = (unsigned char)((data2&0xf)<<4)|((data1&0xf000)>>12);
	lut_mac_entry.mac_addr[3] = (unsigned char)((data1&0xff0)>>4);
	lut_mac_entry.mac_addr[4] = (unsigned char)((data1&0xf)<<4)|((ctrl&0xf00)>>8);
	lut_mac_entry.mac_addr[5] = (unsigned char)(ctrl&0xff);

	return lut_mac_entry;
}
unsigned char lut_get_port_by_mac(unsigned char *pMac, unsigned char *port)
{
	unsigned short index,ctrl,data3;
	struct _lut_mac_entry lut_set; 

  	
	if(lut_get_hash_algorithm()==LUT_HASH_CRC)
	{	
    index = crc_16(pMac);
    ctrl=(index&0xfff)|0x4000;
    write_reg(IP1826_ACCESS_LUT_COMMAND,ctrl);
    while(!(read_reg(IP1826_ACCESS_LUT_COMMAND)&0x8000));//wait for reading LUT.
  	data3=read_reg(IP1826_ACCESS_LUT_DATA_3);	
  	if((data3&0x3c00)==0 || (data3&0x200))
  	{
  		return 0;	
  	}   
    else
    {
      *port=port_num_transfer_R((unsigned char)((data3>>4)&0x1f));
      return 1;
    } 	 
	}
	else
	{
  	index=*(pMac+5);
  	index|=((unsigned short)(*(pMac+4)&0x0f)<<8);
  
  	lut_set = lut_get_mac(index);
  
  	if(lut_set.aging==0)
  	{	
  		return 0;	
  	}
  
  	if(memcmp(pMac,&lut_set.mac_addr,6)==0)
  	{	
  		*port=lut_set.port_num;
  		return 1;
  	}
  }	
  return 0;
}
void lut_set_ip(struct _lut_ip_entry lut_ip_entry)
{
	//lut_entry lut;
	unsigned short ctrl,data1,data2,data3;
	unsigned char i,ipentry[6]={0};
  ctrl=data1=data2=data3=0;		
	
//IP1826_ACCESS_LUT_DATA_1
	/*lut.ip.ip2	= (unsigned short)lut_ip_entry.ip_addr[2];
	lut.ip.ip1	= (unsigned short)lut_ip_entry.ip_addr[1];*/
	data1 = (unsigned short)lut_ip_entry.ip_addr[2] | (unsigned short)lut_ip_entry.ip_addr[1]<<8;
//IP1826_ACCESS_LUT_DATA_2
	/*lut.ip.ip0	= (unsigned short)lut_ip_entry.ip_addr[0];
	lut.ip.port2	= (unsigned short)lut_ip_entry.port_num[2];
	lut.ip.port1L	= (unsigned short)lut_ip_entry.port_num[1]&0x7;*/
	data2 = (unsigned short)lut_ip_entry.ip_addr[0] | ((unsigned short)port_num_transfer(lut_ip_entry.port_num[2])<<8);
  data2 |= (((unsigned short)port_num_transfer(lut_ip_entry.port_num[1])&0x7)<<13); 

//IP1826_ACCESS_LUT_DATA_3
	/*lut.ip.port1H	= (unsigned short)(lut_ip_entry.port_num[1]>>3&0x3);
	lut.ip.port0	= (unsigned short)lut_ip_entry.port_num[0];
	lut.ip.aging	= lut_ip_entry.aging&0x0f;
	lut.ip.cpu		= 0;
	lut.ip.ip_type	= 1;
	lut.ip.type		= 1;*/ 
	data3 = (unsigned short)(port_num_transfer(lut_ip_entry.port_num[1])>>3&0x3) | ((unsigned short)port_num_transfer(lut_ip_entry.port_num[0])<<2);
	data3 |= 0x300;
	data3 |= ((unsigned short)lut_ip_entry.aging&0x0f)<<10;

//IP1826_ACCESS_LUT_COMMAND
	/*lut.ip.ip3		= lut_ip_entry.ip_addr[3];
	lut.ip.ip2L		= (unsigned short)lut_ip_entry.ip_addr[2]&0x0f;
	lut.ip.command	= 0x7;*/
	
  if(lut_get_hash_algorithm()==LUT_HASH_CRC)
	{ 
    for(i=0;i<4;i++)
    { ipentry[i+2] = lut_ip_entry.ip_addr[i]; } 
    ctrl=crc_16((unsigned char *)&ipentry); 
  }
	else
	{  
    ctrl = (unsigned short)lut_ip_entry.ip_addr[3];  
    ctrl |= (((unsigned short)lut_ip_entry.ip_addr[2]&0x0f)<<8);
  } 	

	ctrl |= 0x7000;
//write_reg
	write_reg(IP1826_ACCESS_LUT_DATA_1, data1);
	write_reg(IP1826_ACCESS_LUT_DATA_2, data2);
	write_reg(IP1826_ACCESS_LUT_DATA_3,	data3);
	write_reg(IP1826_ACCESS_LUT_COMMAND,ctrl);

    while(!(read_reg(IP1826_ACCESS_LUT_COMMAND)&0x8000));//wait for reading LUT.
	
}

struct _lut_ip_entry lut_get_ip(unsigned short index)
{
	struct _lut_ip_entry lut_ip_entry;
	//lut_entry lut;
	unsigned short ctrl,data1,data2,data3;
	
	if(lut_get_hash_algorithm()==LUT_HASH_CRC)
	{
		lut_ip_entry.aging=0;
		return lut_ip_entry;
	}	
	
  ctrl=data1=data2=data3=0;
  
  memset(&lut_ip_entry,0x0,sizeof(struct _lut_ip_entry));	
	//lut.reg.ctrl = (index&0xfff);
	ctrl = (index&0xfff);
	ctrl |= 0x4000;
	//lut.ip.command	= 0x4;
	write_reg(IP1826_ACCESS_LUT_COMMAND,ctrl);
	
	while(!(read_reg(IP1826_ACCESS_LUT_COMMAND)&0x8000));//wait for reading LUT.
#ifdef LUT_TWICE_BUG
	write_reg(IP1826_ACCESS_LUT_COMMAND,ctrl);
	while(!(read_reg(IP1826_ACCESS_LUT_COMMAND)&0x8000));//wait for reading LUT.
#endif// LUT_TWICE_BUG
	
	
	data3 = read_reg(IP1826_ACCESS_LUT_DATA_3);
	
	if( (data3&0x3c00)==0 || !(data3&0x200) || !(data3&0x100) )
	{
		lut_ip_entry.aging=0;
		return lut_ip_entry;
	}
		
	data2 = read_reg(IP1826_ACCESS_LUT_DATA_2);  
	data1 = read_reg(IP1826_ACCESS_LUT_DATA_1);

	lut_ip_entry.aging=(unsigned char) ((data3>>10)&0xf);
	lut_ip_entry.port_num[0] =(unsigned char)((data3>>2)&0x1f);
	lut_ip_entry.port_num[0] = port_num_transfer_R(lut_ip_entry.port_num[0]);

	lut_ip_entry.port_num[1] =(unsigned char)((data3&0x3)<<3);
	lut_ip_entry.port_num[1]|=(unsigned char)((data2>>13)&0x3);
	lut_ip_entry.port_num[1] = port_num_transfer_R(lut_ip_entry.port_num[1]);

	lut_ip_entry.port_num[2] =(unsigned char)((data2>>8)&0x1f);
	lut_ip_entry.port_num[2] = port_num_transfer_R(lut_ip_entry.port_num[2]);

	lut_ip_entry.ip_addr[0]		= (unsigned char)(data2&0xff);
	lut_ip_entry.ip_addr[1]		= (unsigned char)((data1>>8)&0xff);
	lut_ip_entry.ip_addr[2]		= (unsigned char)(data1&0xff);
	lut_ip_entry.ip_addr[3]		= (unsigned char)(ctrl&0xff);

	return lut_ip_entry;
}
//========================================================================================
//		SYSTEM
//========================================================================================
unsigned short system_get_ip1826_version(void)
{
	return read_reg(IP1826_VERSION_ID);
}

void system_set_output_queue_aging(unsigned char time)
{
	unsigned short reg_val;
	reg_val = read_reg(IP1826_OUT_QUEUE_SCHEDULE_MODE);
	
	reg_val &= ~(0x3f00);
	reg_val |= ((unsigned short)time&0x3f)<<8;
	write_reg(IP1826_OUT_QUEUE_SCHEDULE_MODE, reg_val);
}

unsigned char system_get_output_queue_aging(void)
{
	return (unsigned short)(read_reg(IP1826_OUT_QUEUE_SCHEDULE_MODE)>>8) & 0x3f;
}

void system_set_output_queue_aging_enable(unsigned char enabled)
{
	write_reg_common(1,IP1826_OUT_QUEUE_SCHEDULE_MODE,15,enabled);
}

unsigned char system_get_output_queue_aging_enable(void)
{
	return read_reg_common(1,IP1826_OUT_QUEUE_SCHEDULE_MODE,15);
}

void system_set_cpu_route_enable(unsigned char enabled)
{
	write_reg_common(1,IP1826_ARL_OPERATION_SETTING,11,enabled);
}

unsigned char system_get_cpu_route_enable(void)
{
	return read_reg_common(1,IP1826_ARL_OPERATION_SETTING,11);
}

void system_set_cpu_route_func(unsigned char func)
{
	write_reg_common(1,IP1826_ARL_OPERATION_SETTING,12,func);
}

unsigned char system_get_cpu_route_func(void)
{
	return read_reg_common(1,IP1826_ARL_OPERATION_SETTING,12);
}

void system_set_switch_mac(unsigned char *mac)
{
    int i;
    unsigned short tmpmac;
    for(i=0;i<3;i++){
        tmpmac = *(mac+(2-i)*2);
        tmpmac <<= 8;
        tmpmac |= *(mac+(2-i)*2+1);
        write_reg(IP1826_SWITCH_MAC+i,tmpmac);
    }
}

void system_get_switch_mac(unsigned char mac[6])
{
    int i;
    unsigned short tmpmac;
    for(i=0;i<3;i++){
        tmpmac = read_reg(IP1826_SWITCH_MAC+i);
        mac[(2-i)*2] = (unsigned char)(tmpmac>>8);
        mac[(2-i)*2+1] = (unsigned char)(tmpmac&0xff);
    }
    return;
}

void system_set_specific_enabled(unsigned char enabled)
{
	write_reg_common(1,IP1826_PACKET_SELECT_PORT_2,10,enabled);
}
unsigned char system_get_specific_enabled(void)
{	
	return read_reg_common(1,IP1826_PACKET_SELECT_PORT_2,10);
}
void system_set_specific_member(unsigned long member)
{
	unsigned short reg_val = read_reg(IP1826_PACKET_SELECT_PORT_2)&0x400;
	member = port_bit_transfer(member);
	write_reg(IP1826_PACKET_SELECT_PORT_1,(unsigned short)(member&0xffff));
	write_reg(IP1826_PACKET_SELECT_PORT_2,(unsigned short)((member>>16)&0x3ff)|reg_val);
}
unsigned long system_get_specific_member(void)
{
	unsigned long member;
	member = read_reg(IP1826_PACKET_SELECT_PORT_1);
	member |= (unsigned long)(read_reg(IP1826_PACKET_SELECT_PORT_2)&0x3ff)<<16;
	return port_bit_transfer_R(member);
}

void system_set_special_tag(unsigned short tag)
{
	write_reg(IP1826_SPECIAL_TAG_SETTING,tag);
}
unsigned short system_get_special_tag(void)
{
	return read_reg(IP1826_SPECIAL_TAG_SETTING);
}

void system_set_led_test(void)
{
	write_reg_common(1,IP1826_LED,8,1);
}

void system_set_led_clock(unsigned char mode)
{
	write_reg_common(1,IP1826_LED,11,mode);
}
#ifndef USER_API

EXPORT_SYMBOL(ip1826_read_reg);
EXPORT_SYMBOL(ip1826_write_reg);

EXPORT_SYMBOL(vlan_set_vid);
EXPORT_SYMBOL(vlan_get_vid);
EXPORT_SYMBOL(vlan_set_across_vlan);
EXPORT_SYMBOL(vlan_get_across_vlan);
EXPORT_SYMBOL(vlan_set_mode);
EXPORT_SYMBOL(vlan_get_mode);
EXPORT_SYMBOL(vlan_set_tag_handling);
EXPORT_SYMBOL(vlan_get_tag_handling);
EXPORT_SYMBOL(vlan_set_member);
EXPORT_SYMBOL(vlan_get_member);
EXPORT_SYMBOL(vlan_set_tag_mode);
EXPORT_SYMBOL(vlan_get_tag_mode);
EXPORT_SYMBOL(vlan_set_addtag);
EXPORT_SYMBOL(vlan_get_addtag);
EXPORT_SYMBOL(vlan_set_rmvtag);
EXPORT_SYMBOL(vlan_get_rmvtag);
EXPORT_SYMBOL(vlan_set_addtag_vid);
EXPORT_SYMBOL(vlan_get_addtag_vid);
EXPORT_SYMBOL(vlan_set_rmvtag_vid);
EXPORT_SYMBOL(vlan_get_rmvtag_vid);
EXPORT_SYMBOL(vlan_set_pvid);
EXPORT_SYMBOL(vlan_get_pvid);
EXPORT_SYMBOL(vlan_set_uplink_enable);
EXPORT_SYMBOL(vlan_get_uplink_enable);
EXPORT_SYMBOL(vlan_set_uplink);
EXPORT_SYMBOL(vlan_get_uplink);
EXPORT_SYMBOL(qos_set_schedule_mode);
EXPORT_SYMBOL(qos_get_schedule_mode);
EXPORT_SYMBOL(qos_set_queue_weight);
EXPORT_SYMBOL(qos_get_queue_weight);
EXPORT_SYMBOL(qos_set_port_enable);
EXPORT_SYMBOL(qos_get_port_enable);
EXPORT_SYMBOL(qos_set_port);
EXPORT_SYMBOL(qos_get_port);
EXPORT_SYMBOL(qos_set_tag_enable);
EXPORT_SYMBOL(qos_get_tag_enable);
EXPORT_SYMBOL(qos_set_tag);
EXPORT_SYMBOL(qos_get_tag);
EXPORT_SYMBOL(qos_set_cos_enable);
EXPORT_SYMBOL(qos_get_cos_enable);
EXPORT_SYMBOL(qos_set_cos);
EXPORT_SYMBOL(qos_get_cos);
EXPORT_SYMBOL(set_protocol_func);
EXPORT_SYMBOL(get_protocol_func);
EXPORT_SYMBOL(set_user_protocol_port);
EXPORT_SYMBOL(get_user_protocol_port);
EXPORT_SYMBOL(set_user_protocol_mask);
EXPORT_SYMBOL(get_user_protocol_mask);
EXPORT_SYMBOL(qos_set_cpu_forward);
EXPORT_SYMBOL(qos_get_cpu_forward);
EXPORT_SYMBOL(qos_set_low_priority);
EXPORT_SYMBOL(qos_get_low_priority);
EXPORT_SYMBOL(qos_set_all);
EXPORT_SYMBOL(security_set_mac_enable);
EXPORT_SYMBOL(security_get_mac_enabled);
EXPORT_SYMBOL(security_set_mac_func);
EXPORT_SYMBOL(security_get_mac_func);
EXPORT_SYMBOL(security_set_auth_enable);
EXPORT_SYMBOL(security_get_auth_enable);
EXPORT_SYMBOL(security_set_auth);
EXPORT_SYMBOL(security_get_auth);
EXPORT_SYMBOL(security_set_auth_func);
EXPORT_SYMBOL(security_get_auth_func);
EXPORT_SYMBOL(security_set_ip_filter_enable);
EXPORT_SYMBOL(security_get_ip_filter_enable);
EXPORT_SYMBOL(security_set_ip_type);
EXPORT_SYMBOL(security_get_ip_type);
EXPORT_SYMBOL(security_set_ip_filter_mode);
EXPORT_SYMBOL(security_get_ip_filter_mode);
EXPORT_SYMBOL(security_set_ip_entry_mode);
EXPORT_SYMBOL(security_get_ip_entry_mode);
EXPORT_SYMBOL(security_set_ip_shift);
EXPORT_SYMBOL(security_get_ip_shift);
EXPORT_SYMBOL(security_set_l2l3_func);
EXPORT_SYMBOL(security_get_l2l3_func);
EXPORT_SYMBOL(port_set_enable);
EXPORT_SYMBOL(port_get_enable);
EXPORT_SYMBOL(port_get_fiber);
EXPORT_SYMBOL(port_set_fiber_AD);
EXPORT_SYMBOL(port_set_restart_AN_fiber);
EXPORT_SYMBOL(port_set_restart_AN);
EXPORT_SYMBOL(port_set_auto_fiber);
EXPORT_SYMBOL(port_get_auto_fiber);
EXPORT_SYMBOL(port_set_auto);
EXPORT_SYMBOL(port_get_auto);
EXPORT_SYMBOL(port_get_an_complete);
EXPORT_SYMBOL(port_set_auto_all);
EXPORT_SYMBOL(port_get_auto_all);
EXPORT_SYMBOL(port_set_speed);
EXPORT_SYMBOL(port_get_speed);
EXPORT_SYMBOL(port_set_speed_all);
EXPORT_SYMBOL(port_get_speed_all);
EXPORT_SYMBOL(port_set_speed_GIGA);
EXPORT_SYMBOL(port_get_speed_GIGA);
EXPORT_SYMBOL(port_set_mdi_auto);
EXPORT_SYMBOL(port_get_mdi_auto);
EXPORT_SYMBOL(port_set_mdi_mode);
EXPORT_SYMBOL(port_get_mdi_mode);
EXPORT_SYMBOL(port_set_duplex);
EXPORT_SYMBOL(port_get_duplex);
EXPORT_SYMBOL(port_set_duplex_all);
EXPORT_SYMBOL(port_get_duplex_all);
EXPORT_SYMBOL(port_set_rx_enable);
EXPORT_SYMBOL(port_get_rx_enable);
EXPORT_SYMBOL(port_set_rx_enable_all);
EXPORT_SYMBOL(port_get_rx_enable_all);
EXPORT_SYMBOL(port_set_tx_enable);
EXPORT_SYMBOL(port_get_tx_enable);
EXPORT_SYMBOL(port_set_tx_enable_all);
EXPORT_SYMBOL(port_get_tx_enable_all);
EXPORT_SYMBOL(port_set_learning);
EXPORT_SYMBOL(port_get_learning);
EXPORT_SYMBOL(port_set_learning_all);
EXPORT_SYMBOL(port_get_learning_all);
EXPORT_SYMBOL(port_set_forwarding);
EXPORT_SYMBOL(port_get_forwarding);
EXPORT_SYMBOL(port_set_forwarding_all);
EXPORT_SYMBOL(port_get_forwarding_all);
EXPORT_SYMBOL(port_set_pause_fiber);
EXPORT_SYMBOL(port_get_pause_fiber);
EXPORT_SYMBOL(port_set_pause);
EXPORT_SYMBOL(port_get_pause);
EXPORT_SYMBOL(port_set_pause_all);
EXPORT_SYMBOL(port_get_pause_all);
EXPORT_SYMBOL(port_set_backpressure);
EXPORT_SYMBOL(port_get_backpressure);
EXPORT_SYMBOL(port_set_backpressure_all);
EXPORT_SYMBOL(port_get_backpressure_all);
EXPORT_SYMBOL(port_set_backpressure_func);
EXPORT_SYMBOL(port_get_backpressure_func);
EXPORT_SYMBOL(port_set_broadcast_storm_protection);
EXPORT_SYMBOL(port_get_broadcast_storm_protection);
EXPORT_SYMBOL(port_set_broadcast_storm_threshold);
EXPORT_SYMBOL(port_get_broadcast_storm_threshold);
EXPORT_SYMBOL(port_set_port_mirror);
EXPORT_SYMBOL(port_get_port_mirror);
EXPORT_SYMBOL(port_set_port_mirror_mode);
EXPORT_SYMBOL(port_get_port_mirror_mode);
EXPORT_SYMBOL(port_set_non_associate_enable);
EXPORT_SYMBOL(port_get_non_associate_enable);
EXPORT_SYMBOL(port_set_non_associate);
EXPORT_SYMBOL(port_get_non_associate);
EXPORT_SYMBOL(port_set_bandwidth);
EXPORT_SYMBOL(port_get_bandwidth);
EXPORT_SYMBOL(port_set_bandwidth_func);
EXPORT_SYMBOL(port_get_bandwidth_func);
EXPORT_SYMBOL(port_set_counter_enable);
EXPORT_SYMBOL(port_get_counter_enable);
EXPORT_SYMBOL(port_set_counter_mode);
EXPORT_SYMBOL(port_get_counter_mode);
EXPORT_SYMBOL(port_set_counter_select);
EXPORT_SYMBOL(port_get_counter_select);
EXPORT_SYMBOL(port_set_wanfilter);
EXPORT_SYMBOL(port_get_wanfilter);
EXPORT_SYMBOL(port_set_wanfilter_all);
EXPORT_SYMBOL(port_get_wanfilter_all);
EXPORT_SYMBOL(port_set_wanfilter_mode);
EXPORT_SYMBOL(port_get_wanfilter_mode);
EXPORT_SYMBOL(port_set_wanfilter_enable);
EXPORT_SYMBOL(port_get_wanfilter_enable);
EXPORT_SYMBOL(port_set_wanfilter_protocol);
EXPORT_SYMBOL(port_get_wanfilter_protocol);
EXPORT_SYMBOL(port_set_wanfilter_protocol_all);
EXPORT_SYMBOL(port_get_wanfilter_protocol_all);
EXPORT_SYMBOL(port_get_status);
EXPORT_SYMBOL(port_get_status_GIGA);
EXPORT_SYMBOL(port_get_link);
EXPORT_SYMBOL(port_get_link_fiber);
EXPORT_SYMBOL(port_get_counter);
EXPORT_SYMBOL(port_clear_counter);
EXPORT_SYMBOL(port_set_force_link);
EXPORT_SYMBOL(port_get_force_link);
EXPORT_SYMBOL(set_bpdu_bcast);
EXPORT_SYMBOL(get_bpdu_bcast);
EXPORT_SYMBOL(set_cpu_interface_mode);
EXPORT_SYMBOL(get_cpu_interface_mode);
EXPORT_SYMBOL(set_special_tag_enable);
EXPORT_SYMBOL(get_special_tag_enable);
EXPORT_SYMBOL(set_cpu_mode_enable);
EXPORT_SYMBOL(get_cpu_mode_enable);
EXPORT_SYMBOL(stp_set_port_state);
EXPORT_SYMBOL(stp_get_port_state);
EXPORT_SYMBOL(trunk_set_group_member);
EXPORT_SYMBOL(trunk_get_group_member);
EXPORT_SYMBOL(trunk_set_func);
EXPORT_SYMBOL(trunk_get_func);
EXPORT_SYMBOL(igmp_set_func);
EXPORT_SYMBOL(igmp_get_func);
EXPORT_SYMBOL(igmp_set_router_port);
EXPORT_SYMBOL(igmp_get_router_port);
EXPORT_SYMBOL(igmp_set_enabled);
EXPORT_SYMBOL(igmp_get_enabled);
EXPORT_SYMBOL(set_block_bcast_to_cpu);
EXPORT_SYMBOL(get_block_bcast_to_cpu);
EXPORT_SYMBOL(set_pass_ipv4_to_cpu);
EXPORT_SYMBOL(get_pass_ipv4_to_cpu);
EXPORT_SYMBOL(lut_set_hash_algorithm);
EXPORT_SYMBOL(lut_get_hash_algorithm);
EXPORT_SYMBOL(lut_flush_table);
EXPORT_SYMBOL(lut_flush_port);
EXPORT_SYMBOL(lut_flush_igmp);
EXPORT_SYMBOL(lut_scan_mac);
EXPORT_SYMBOL(lut_set_mac);
EXPORT_SYMBOL(lut_get_mac);
EXPORT_SYMBOL(lut_get_port_by_mac);
EXPORT_SYMBOL(lut_set_ip);
EXPORT_SYMBOL(lut_get_ip);
EXPORT_SYMBOL(system_get_ip1826_version);
EXPORT_SYMBOL(system_set_output_queue_aging);
EXPORT_SYMBOL(system_get_output_queue_aging);
EXPORT_SYMBOL(system_set_output_queue_aging_enable);
EXPORT_SYMBOL(system_get_output_queue_aging_enable);
EXPORT_SYMBOL(system_set_cpu_route_enable);
EXPORT_SYMBOL(system_get_cpu_route_enable);
EXPORT_SYMBOL(system_set_cpu_route_func);
EXPORT_SYMBOL(system_get_cpu_route_func);
EXPORT_SYMBOL(system_set_switch_mac);
EXPORT_SYMBOL(system_get_switch_mac);
EXPORT_SYMBOL(system_set_specific_enabled);
EXPORT_SYMBOL(system_get_specific_enabled);
EXPORT_SYMBOL(system_set_specific_member);
EXPORT_SYMBOL(system_get_specific_member);
EXPORT_SYMBOL(system_set_special_tag);
EXPORT_SYMBOL(system_get_special_tag);
EXPORT_SYMBOL(system_set_led_test);
EXPORT_SYMBOL(system_set_led_clock);

#endif