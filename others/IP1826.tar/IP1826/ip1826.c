#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/slab.h>
#include <linux/mutex.h>
#include <asm/uaccess.h>
//**************************************

#include "ip1826.h"
#include "ip1826lib.h"
MODULE_LICENSE("Dual BSD/GPL");

//***************************************************************************
// MDIO
//***************************************************************************
#define IP1826_GPIO_MDIO


#ifdef IP1826_GPIO_MDIO
#define MDIO_DELAY	1000
#define MDIO_RD		0
#define MDIO_WR		1



#ifdef IP1829_GPIO_FUNC
//--------------   example : ip1829 project GPIO function ---------------------
#define GPIO_MDIO_OFFSET 0x0
#define GPIO_MDC_OFFSET 0x1
#include <asm/io.h>
static DEFINE_MUTEX(ip1826_gpio_lock);
#define IP1829_GPIO_BASE      0xBEE00000
#define IP1829_GPIO_OUTPUT_VALUE_0_OFFSET	0x0018
#define IP1829_GPIO_OUTPUT_ENABLE_0_OFFSET	0x0020 
#define IP1829_GPIO_DIRECTION_0_OFFSET		0x0008 
#define IP1829_GPIO_INPUT_VALUE_0_OFFSET	0x0010
#define IP1829_GPIO_SET_VALUE_1 0x1
#define IP1829_GPIO_SET_VALUE_0 0x0
static int ip1829_gpio_get(unsigned offset)
{
	void __iomem				*base;
	void __iomem				*base_offset = 0x0000;
	u32					val;
	
	mutex_lock(&ip1826_gpio_lock);

	if((0<=offset)&&(offset<=31))
		base_offset = 0x0000;
	else if((32<=offset)&&(offset<=47)) {
		base_offset = (void __iomem *)0x0004;
		offset -= 32;
	}

	base = IP1829_GPIO_BASE + base_offset + IP1829_GPIO_INPUT_VALUE_0_OFFSET;
	val = readl(base);
	val = ((val & BIT(offset))>>offset);

	mutex_unlock(&ip1826_gpio_lock);

	return val;
}
static void ip1829_gpio_set(unsigned offset,int value)
{
	void __iomem				*base;
	void __iomem				*base_offset = 0x0000;
	u32					val;

	mutex_lock(&ip1826_gpio_lock);

	if((0<=offset)&&(offset<=31))
		base_offset = 0x0000;
	else if((32<=offset)&&(offset<=47)) {
		base_offset = (void __iomem *)0x0004;
		offset -= 32;
	}

	base = IP1829_GPIO_BASE + base_offset + IP1829_GPIO_OUTPUT_VALUE_0_OFFSET;
	val = readl(base);
	val = (value == IP1829_GPIO_SET_VALUE_1) ? (val | BIT(offset)) : (val & ~((BIT(offset))));
	writel(val, base);

	mutex_unlock(&ip1826_gpio_lock);

	return;
}
static int ip1829_gpio_direction_out(unsigned offset,int value)
{
	void __iomem				*base;
	void __iomem				*base_offset = 0x0000;
	u32					val;

	mutex_lock(&ip1826_gpio_lock);

	if((0<=offset)&&(offset<=31))
		base_offset = 0x0000;
	else if((32<=offset)&&(offset<=47)) {
		base_offset = (void __iomem *)0x0004;
		offset -= 32;
	}

	base = IP1829_GPIO_BASE + base_offset + IP1829_GPIO_DIRECTION_0_OFFSET;
	val = readl(base);
	val |= BIT(offset);
	writel(val, base);

	base = IP1829_GPIO_BASE + base_offset + IP1829_GPIO_OUTPUT_VALUE_0_OFFSET;
	val = readl(base);
	val = (value == IP1829_GPIO_SET_VALUE_1) ? (val | BIT(offset)) : (val & ~((BIT(offset))));
	writel(val, base);

	base = IP1829_GPIO_BASE + base_offset + IP1829_GPIO_OUTPUT_ENABLE_0_OFFSET;
	val = readl(base);
	val |= BIT(offset);
	writel(val, base);

	mutex_unlock(&ip1826_gpio_lock);

	return 0;
}
static int ip1829_gpio_direction_in( unsigned offset)
{
	void __iomem				*base;
	void __iomem				*base_offset = 0x0000;
	u32					val;

	mutex_lock(&ip1826_gpio_lock);

	if((0<=offset)&&(offset<=31))
		base_offset = 0x0000;
	else if((32<=offset)&&(offset<=47)) {
		base_offset = (void __iomem *)0x0004;
		offset -= 32;
	}

	base = IP1829_GPIO_BASE + base_offset + IP1829_GPIO_OUTPUT_ENABLE_0_OFFSET;
	val = readl(base);
	val &= ~(BIT(offset));
	writel(val, base);

	base = IP1829_GPIO_BASE + base_offset + IP1829_GPIO_DIRECTION_0_OFFSET;
	val = readl(base);
	val &= ~(BIT(offset));
	writel(val, base);

	base = IP1829_GPIO_BASE + base_offset + IP1829_GPIO_INPUT_VALUE_0_OFFSET;
	val = readl(base);
	val = ((val & BIT(offset))>>offset);

	mutex_unlock(&ip1826_gpio_lock);

	return val;
}

#endif
//-------------------------------------------------------------------------------------

void ic_mdio_init(void)
{
#ifdef IP1829_GPIO_FUNC
  ip1829_gpio_direction_out(GPIO_MDC_OFFSET,0);
  ip1829_gpio_direction_out(GPIO_MDIO_OFFSET,0);
#endif  
}
void mdio_set_MDC_MDIO_direction(unsigned char mdc, unsigned char mdio)//0:input, 1:output for mdc/mdio values
{
#ifdef IP1829_GPIO_FUNC
    if(mdc) ;
    if(mdio)
      ip1829_gpio_direction_out(GPIO_MDIO_OFFSET,0);
    else
      ip1829_gpio_direction_in(GPIO_MDIO_OFFSET);
#endif         
}

void mdio_set_MDC_1(void)
{
#ifdef IP1829_GPIO_FUNC
      ip1829_gpio_set(GPIO_MDC_OFFSET,1);
#endif      
}
void mdio_set_MDC_0(void)
{ 
#ifdef IP1829_GPIO_FUNC 
      ip1829_gpio_set(GPIO_MDC_OFFSET,0);
#endif      
}
void mdio_set_MDIO_1(void)
{
#ifdef IP1829_GPIO_FUNC
      ip1829_gpio_set(GPIO_MDIO_OFFSET,1);
#endif      
}
void mdio_set_MDIO_0(void)
{
#ifdef IP1829_GPIO_FUNC
      ip1829_gpio_set(GPIO_MDIO_OFFSET,0);
#endif      
}
unsigned int mdio_get_MDIO_value(void)
{
#ifdef IP1829_GPIO_FUNC
  return ip1829_gpio_get(GPIO_MDIO_OFFSET);
#endif  
}

void mdio_1(void){
	int i=0;

//set MDIO to 1
//set MDC to 0
        mdio_set_MDIO_1();
        mdio_set_MDC_0();

	for(i=0;i<MDIO_DELAY;i++);
	for(i=0;i<MDIO_DELAY;i++);

//set MDIO to 1
//set MDC to 1
        mdio_set_MDIO_1();
        mdio_set_MDC_1();

	for(i=0;i<MDIO_DELAY;i++);
	for(i=0;i<MDIO_DELAY;i++);

}

void mdio_0(void){
	int i=0;

//set MDIO to 0
//set MDC to 0
        mdio_set_MDIO_0();
        mdio_set_MDC_0();

	for(i=0;i<MDIO_DELAY;i++);
	for(i=0;i<MDIO_DELAY;i++);

//set MDIO to 0
//set MDC to 1
        mdio_set_MDIO_0();
        mdio_set_MDC_1();

	for(i=0;i<MDIO_DELAY;i++);
	for(i=0;i<MDIO_DELAY;i++);

}

void mdio_z(void){
	int i=0;

//set MDC to 0
        mdio_set_MDC_0();

	for(i=0;i<MDIO_DELAY;i++);
	for(i=0;i<MDIO_DELAY;i++);
//set MDC to 1
        mdio_set_MDC_1();

	for(i=0;i<MDIO_DELAY;i++);
	for(i=0;i<MDIO_DELAY;i++);
}

void mdio_start(void){
	mdio_0();
	mdio_1();
}

void mdio_rw(int rw){
	if(rw==MDIO_RD){
		mdio_1();
		mdio_0();
	}else{
		mdio_0();
		mdio_1();
	}
}

void ic_mdio_wr(unsigned short pa, unsigned short ra, unsigned short va){
	int i=0;
	unsigned short data=0;

//set MDC/MDIO pins to GPIO mode
	ic_mdio_init();

//set MDC direction to output
//set MDIO direction to output
        mdio_set_MDC_MDIO_direction(1,1);

	for(i=0;i<32;i++)
		mdio_1();
	mdio_start();
	mdio_rw(MDIO_WR);
	for(i=0;i<5;i++){
		if((pa>>(5-1-i))%2)
			mdio_1();
		else
			mdio_0();
	}
	for(i=0;i<5;i++){
		if((ra>>(5-1-i))%2)
			mdio_1();
		else
			mdio_0();
	}
	mdio_1();
	mdio_0();
	for(i=0;i<16;i++){
		data=va<<i;
		data=data>>15;
		if(data==1)
			mdio_1();
		else
			mdio_0();
	}
}

unsigned short ic_mdio_rd(unsigned short pa, unsigned short ra){
	int i=0,j=0;
	unsigned short data=0;
        int regBit;
        unsigned char debug[16];

//set MDC/MDIO pins to GPIO mode
	ic_mdio_init();

//set MDC/MDIO PIN direction
//mdio_set_MDC_MDIO_dir();
//MDC direction set to output
//MDIO direction set to output
        mdio_set_MDC_MDIO_direction(1,1);

	for(i=0;i<32;i++)
		mdio_1();
	mdio_start();
	mdio_rw(MDIO_RD);
	for(i=0;i<5;i++){
		if((pa>>(5-1-i))%2)
			mdio_1();
		else
			mdio_0();
	}
	for(i=0;i<5;i++){
		if((ra>>(5-1-i))%2)
			mdio_1();
		else
			mdio_0();
	}
	mdio_z();
	mdio_0();

//set MDC/MDIO PIN direction
//mdio_set_MDC_MDIO_dir();
//MDIO DIR set to input
        mdio_set_MDC_MDIO_direction(1,0);

	for(j=0;j<16;j++){
		//regBit=mdio_readbit();
//MDC set to 0
                mdio_set_MDC_0();

		for(i=0;i<MDIO_DELAY;i++);
		for(i=0;i<MDIO_DELAY;i++);

//get MDIO value
                regBit=mdio_get_MDIO_value();

		if(regBit==0)
                {
			data|=0;
                debug[15-j]=0;
                }
		else
                {
			data|=1;
                debug[15-j]=1;
                }
		if(j<15)
			data=data<<1;

//MDC set to 1
                mdio_set_MDC_1();

		for(i=0;i<MDIO_DELAY;i++);
		for(i=0;i<MDIO_DELAY;i++);
	}
//MDC set to 0
        mdio_set_MDC_0();

	for(i=0;i<MDIO_DELAY;i++);
	for(i=0;i<MDIO_DELAY;i++);
//	reg=GPREG(GPVAL);
//MDC set to 1
        mdio_set_MDC_1();

	for(i=0;i<MDIO_DELAY;i++);
	for(i=0;i<MDIO_DELAY;i++);

	return data;
}
#endif
//***************************************************************************
unsigned short ip1826_mdio_rd(unsigned short pa, unsigned short ra)
{
#ifdef IP1826_GPIO_MDIO
  return ic_mdio_rd(pa,ra);
#else
#endif  
}
void ip1826_mdio_wr(unsigned short pa, unsigned short ra, unsigned short va)
{
#ifdef IP1826_GPIO_MDIO
  ic_mdio_wr(pa,ra,va);
#else
#endif 
}



static struct cdev ip1826_cdev;
static int ip1826_major = 249;
static DEFINE_MUTEX(ip1826_mutex);

#define IP1826_NAME	"ip1826_cdev"


static int ip1826_open(struct inode *inode, struct file *fs)
{
#ifdef IP1826DEBUG
	printk("ip1826: open...\n");
#endif
	try_module_get(THIS_MODULE);

	return 0;
}

static int ip1826_release(struct inode *inode, struct file *file)
{
	module_put(THIS_MODULE);
#ifdef IP1826DEBUG
	printk("ip1826: release!\n");
#endif
	return 0;
}

static ssize_t ip1826_read(struct file *filp, char __user *buffer, size_t length, loff_t *offset)
{
	return 0;
}

static ssize_t ip1826_write(struct file *filp, const char __user *buff, size_t len, loff_t *off)
{
	return 0;
}

static int ip1826_ioctl(struct file *filep, unsigned int cmd, unsigned long arg)
{
	unsigned long len, rwcmd;
	unsigned short regaddr,regdata;
	void *cptr;
	char *cdata;
	int ret=0x0;

#ifdef IP1826DEBUG
	printk(KERN_ALERT "ip1826: +ioctl...\n");
#endif
	len = (int)(_IOC_SIZE(cmd));
	rwcmd = (int)(_IOC_DIR(cmd));
	cptr = (void *)arg;
  

		cdata = kmalloc(len, GFP_KERNEL);
		if (!cdata)
		{
			ret = -ENOMEM;
			goto out_ip1826_ioctl;
		}

		if (copy_from_user(cdata, cptr, len))
		{
			ret = -EFAULT;
			goto out_ip1826_ioctl;
		}
		regaddr = *((unsigned short *)(cdata));
		regdata = *((unsigned short *)(cdata+2));

#ifdef IP1826DEBUG
		printk(KERN_ALERT "regaddr=0x%04x  regdata=0x%04x\n", (unsigned short)regaddr,(unsigned short)regdata);
#endif
    if(regaddr>0xff)
    {
      ret = -EINVAL;
      goto out_ip1826_ioctl;
    }
    switch(cmd)
    {
        case IP1826_READ:
#ifdef IP1826DEBUG
		printk(KERN_ALERT "IP1826_READ regaddr=0x%04x  regdata=0x%04x\n", (unsigned short)regaddr,(unsigned short)regdata);
#endif        
          *((unsigned short *)(cdata+2)) = ip1826_mdio_rd(((regaddr)>>5)&0x1f,(regaddr)&0x1f);
          break;
        case IP1826_WRITE:
#ifdef IP1826DEBUG
    printk(KERN_ALERT "IP1826_WRITE regaddr=0x%04x  regdata=0x%04x\n", (unsigned short)regaddr,(unsigned short)regdata);  
#endif 
          ip1826_mdio_wr(((regaddr)>>5)&0x1f,(regaddr)&0x1f,regdata);         
          break;
    }
		if (copy_to_user(cptr, cdata, len))
		{
			ret = -EFAULT;
			goto out_ip1826_ioctl;
		}
		cptr= (void *)*((unsigned long *)cdata);
		len = *((unsigned long *)(cdata+4));

		kfree(cdata);
		cdata = NULL;
		
out_ip1826_ioctl:
	if(cdata)
	{
		//memset(cdata, 0x0, len);
		kfree(cdata);
	}
#ifdef IP1826DEBUG
	printk(KERN_ALERT "ip1826: -ioctl...\n");
#endif
	return (ret < 0) ? ret : 0;
}

static long ip1826_unlocked_ioctl(struct file *filep, unsigned int cmd, unsigned long arg)
{
	int ret;

	mutex_lock(&ip1826_mutex);
	ret = ip1826_ioctl(filep, cmd, arg);
	mutex_unlock(&ip1826_mutex);

	return ret;
}

static struct file_operations ip1826_fops = {
	.owner			= THIS_MODULE,
	.read			= ip1826_read, 
	.write			= ip1826_write,
	.unlocked_ioctl	= ip1826_unlocked_ioctl,
	.open			= ip1826_open,
	.release		= ip1826_release
};

static int __init ip1826_init(void)
{
	int result;

  //lut_set_hash_algorithm(LUT_HASH_DIRECT);
	result = register_chrdev_region(MKDEV(ip1826_major, 0), 1, IP1826_NAME);
	if (result < 0)
	{
    printk(KERN_WARNING "ip1826: can't get major %d\n", ip1826_major);
    return result;
	}

	cdev_init(&ip1826_cdev, &ip1826_fops);
	ip1826_cdev.owner = THIS_MODULE;
	result = cdev_add(&ip1826_cdev, MKDEV(ip1826_major, 0), 1);
	if (result)
	{
		printk(KERN_WARNING "ip1826: error %d adding driver\n", result);
		return result;
	}
	else
	{
		printk("ip1826: driver loaded!\n");
 		return 0;
	}
}

static void __exit ip1826_exit(void)
{
	cdev_del(&ip1826_cdev);
	unregister_chrdev_region(MKDEV(ip1826_major, 0), 1);
	printk("ip1826: driver unloaded!\n");
}  

module_init(ip1826_init);
module_exit(ip1826_exit);
