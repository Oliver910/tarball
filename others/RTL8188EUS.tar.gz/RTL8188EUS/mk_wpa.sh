#!/bin/bash


# --------------------- modify PATH -----------------------
NFS_PATH=/home/aurora/HTNAS/sbin
NFS_ETC_PATH=/home/aurora/HTNAS/etc
HUNT_WPA_PATH=$1
WPA_DIR=wpa_supplicant_hostapd-0.8_rtw_r7475.20130812
# ---------------------------------------------------------


# ----- wpa_supplicant # -----
cd wpa_supplicant_hostapd
tar zxvf $WPA_DIR.tar.gz
cd $WPA_DIR/wpa_supplicant

echo "######  Hi3535  ######" >> .config
echo "CC=arm-hisiv200-linux-gcc -I../../../..glibc/include" >> .config
echo "CFLAGS+=-I../../../..glibc/include" >> .config
echo "LDFLAGS += -L../../../../glibc/lib" >> .config
echo "LIBS += -lssl -lcrypto" >> .config

make clean all
echo $HUNT_WPA_PATH
cp wpa_supplicant wpa_cli ../../wpa_supplicant.conf  $HUNT_WPA_PATH
cp wpa_supplicant wpa_cli ../../wpa_supplicant.conf  $NFS_PATH

cd ../hostapd
echo "CC=arm-hisiv200-linux-gcc -I../../../..glibc/include" >> .config
make clean all
echo $HUNT_WPA_PATH
cp hostapd hostapd_cli hostapd.accept hostapd.deny $HUNT_WPA_PATH
cp hostapd hostapd_cli $NFS_PATH
cp hostapd.accept hostapd.deny $NFS_ETC_PATH
cd ../..
cp hostapd_2G.conf $HUNT_WPA_PATH 
cp hostapd_2G.conf $NFS_ETC_PATH

cd ../

echo "Build wpa_supplicant and hostapd is completed !"