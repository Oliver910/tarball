/*
 * Worldvisions Weaver Software:
 *   Copyright (C) 1997-2002 Net Integration Technologies, Inc.
 * 
 * A placeholder for applications that want to link to UniConf moniker
 * objects, but are linking dynamically to wvstreams instead of statically
 * (in which case, you *always* get all the monikers anyway).
 * 
 * See unigenhack_s.cc for what happens when you link statically.
 */
#include "wvlinkerhack.h"

WV_LINK(UniGenHack);

