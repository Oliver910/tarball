/*
 * testhandler.h 
 */

void            init_vacm_context(void);
Netsnmp_Node_Handler vacm_context_handler;
